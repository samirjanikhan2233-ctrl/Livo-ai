# Google Play Store Listing — Livo AI

**App name:** Livo AI
**Developer:** MuhammadSamirKhankabir
**Category:** Productivity
**Content rating:** Everyone (pending official Content Rating questionnaire — see checklist below)

## Short description (max 80 characters)
AI assistant for tasks, habits, goals, finance & notes — plan your day smarter.

## Full description (max 4000 characters)
Livo AI is your all-in-one AI-powered personal assistant and productivity companion.

Chat with a real AI assistant to plan your day, break down your goals, and get productivity
ideas — then manage everything in one place:

📅 SMART DAILY PLANNER
Create, edit and complete tasks with priorities, due dates, reminders and recurring tasks.
See Today, Tomorrow, This Week and Completed at a glance.

🔥 HABIT TRACKER
Build habits that stick with daily/weekly/monthly views, current and best streaks, and healthy,
non-manipulative gamification.

🎯 GOALS
Turn big ambitions — study, fitness, business, saving money, learning a skill — into concrete
milestones, with AI-powered goal breakdowns and visual progress tracking.

💰 FINANCE TRACKER
Log income and expenses across categories like Food, Transport, Bills and more. See your
balance, monthly spending, category breakdown and set monthly budgets. Ask the AI assistant
where you're spending the most or how to build a budget (informational only, not professional
financial advice).

📝 NOTES
Create, pin, archive and search notes, with one-tap AI summaries for long notes.

🤖 REAL AI ASSISTANT
A genuine AI chat experience with conversation history, regenerate/copy responses, and
suggested prompts — not a scripted chatbot.

🏆 XP & ACHIEVEMENTS
Earn XP for completing tasks, habits and goals, level up, and unlock achievements — all
designed around healthy motivation, never gambling-style mechanics.

⭐ PREMIUM
Upgrade for higher AI limits, advanced analytics, premium themes and a completely ad-free
experience. Free users get full core functionality with ads.

Livo AI works offline for your everyday tasks, notes and finance entries, and syncs
automatically once you're back online.

Developed by MuhammadSamirKhankabir.

## Screenshots checklist (Play Console requires at minimum 2 phone screenshots; 16:9 or 9:16, JPEG/PNG)
- [ ] Onboarding — "Meet Livo AI"
- [ ] Home dashboard (greeting, progress, XP, quick actions)
- [ ] AI chat screen with a real conversation
- [ ] Planner — Today view with a mix of priorities
- [ ] Habits — streak view
- [ ] Finance — summary + category breakdown
- [ ] Goals — a goal with milestones and progress
- [ ] Premium screen (monthly/yearly plans)
- [ ] Feature graphic (1024×500) for the store listing header
- [ ] App icon (512×512, 32-bit PNG with alpha)

## Privacy Policy URL
[ Insert your published Privacy Policy URL — e.g. https://yourdomain.com/livo-ai/privacy ]
(placeholder currently in app: see util/Constants.kt PRIVACY_POLICY_URL)

## Data Safety section (Play Console) — preparation notes
Declare truthfully based on your final backend implementation. As built, this reference app:
- Collects: Name, Email, App activity (tasks/habits/goals/notes/finance you create), 
  Device/other IDs (for crash reporting), and messages you send to the AI assistant.
- Data is transmitted over HTTPS/TLS.
- Users can request data deletion in-app (Profile → Delete Account).
- No data is sold to third parties.
- Data shared with: AI provider (to generate responses), Google Play Billing (purchases),
  Firebase (auth/crash reporting) — update this if you swap providers.

## Content Rating preparation
Fill out Play Console's Content Rating questionnaire (IARC). Livo AI as designed contains no
violence, sexual content, gambling mechanics, or user-generated public content — expect an
"Everyone" rating, but the official rating is only assigned after you submit the questionnaire.

## App category
Productivity (primary). Consider "Finance" or "Tools" as a secondary consideration, but
Productivity best matches the core use case.

## Versioning
- versionName: 1.0.0 (user-facing, e.g. "1.0.0", "1.1.0")
- versionCode: 1 (integer, must increase on every Play Store upload)

## Release checklist before uploading the AAB
- [ ] Real google-services.json added (Firebase)
- [ ] Real AdMob App ID / Ad Unit IDs configured (production, not test IDs)
- [ ] Real subscription products created in Play Console (livo_ai_premium_monthly, livo_ai_premium_yearly)
- [ ] Backend deployed at a real HTTPS URL, BACKEND_BASE_URL updated
- [ ] Release keystore generated and kept safe (see README "Release signing")
- [ ] Privacy Policy hosted at a public URL and linked in Play Console + in-app
- [ ] Data Safety form completed accurately
- [ ] Content Rating questionnaire completed
- [ ] Internal testing track used before any production rollout
