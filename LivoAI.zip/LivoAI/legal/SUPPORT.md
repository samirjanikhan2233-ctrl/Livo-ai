# Support — Livo AI

**Developer:** MuhammadSamirKhankabir

Need help with Livo AI?

- **Email:** [SUPPORT EMAIL]
- **Response time:** [e.g. within 2 business days]

## Common requests
- Account & login issues
- Restoring a Premium purchase (also try Premium → Restore purchases in-app)
- Reporting a bug (please include your app version, Android version, and steps to reproduce)
- Requesting account or data deletion (also available in-app: Profile → Delete Account)

## Data deletion
You can delete your account and all associated data at any time from **Profile → Delete
Account** inside the app. If you need help, email us at the address above with your account
email and we will process the deletion within [TIMEFRAME].
