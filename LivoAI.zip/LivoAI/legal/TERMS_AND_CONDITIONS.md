# Terms & Conditions — Livo AI

**Developer:** MuhammadSamirKhankabir
**Last updated:** [DATE]

Replace all `[BRACKETED]` fields with your real information before publishing.

## 1. Acceptance of Terms
By downloading or using Livo AI, you agree to these Terms & Conditions and our Privacy Policy.

## 2. Use of the App
Livo AI is provided for personal productivity use. You agree not to misuse the AI Assistant,
attempt to access other users' data, reverse-engineer the app, or use it for unlawful purposes.

## 3. AI-Generated Content
AI suggestions (daily plans, goal breakdowns, finance insights, note summaries) are provided
for informational and productivity purposes only. They are **not** professional financial,
medical, or legal advice, and Livo AI is not liable for decisions made based on AI output.

## 4. Subscriptions & Billing
Premium subscriptions (monthly/yearly) are billed and managed through Google Play Billing and
renew automatically until cancelled. Manage or cancel your subscription from the Google Play
Store app on your device. Refunds are handled per Google Play's refund policy.

## 5. Free vs Premium Tier
Free-tier users may see AdMob advertising. Premium subscribers receive an ad-free experience
and higher AI usage limits, as described in the app's Premium screen.

## 6. Account Termination
You may delete your account at any time. We may suspend or terminate accounts that violate
these Terms.

## 7. Limitation of Liability
Livo AI is provided "as is" without warranties of any kind, to the maximum extent permitted by
applicable law.

## 8. Changes to These Terms
We may update these Terms from time to time. Continued use of the app after changes means you
accept the updated Terms.

## 9. Contact
Questions about these Terms: **[SUPPORT EMAIL]**.
