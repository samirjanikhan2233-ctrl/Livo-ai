# Privacy Policy — Livo AI

**Developer:** MuhammadSamirKhankabir
**Last updated:** [DATE]

This is a placeholder Privacy Policy structured for a real productivity/AI app. Replace all
`[BRACKETED]` fields with your real information before publishing, and host this (or the
equivalent in-app screen) at a public URL — Google Play requires a live Privacy Policy URL.

## 1. Information We Collect
- **Account data:** name, email address (via Firebase Authentication).
- **Content you create:** tasks, habits, goals, notes, finance entries, AI chat messages.
- **Usage & device data:** crash logs, basic analytics, notification tokens.

## 2. How We Use Your Information
- To operate Livo AI's core features (planner, habits, goals, finance, notes, AI assistant).
- To process Premium subscriptions through Google Play Billing.
- To send reminders and notifications you've enabled.
- To improve reliability (crash reporting) and, in aggregate/anonymized form, the product.

## 3. AI Processing
When you use the AI Assistant, your message (and, for context, a portion of your recent chat
history) is sent to our backend and forwarded to a third-party AI provider to generate a
response. We do not sell this content, and we do not use your private notes or finance data to
train third-party AI models without additional, explicit consent.

## 4. Data Sharing
We do not sell personal data. We share data only with service providers required to run the
app: hosting/infrastructure, our AI provider, Google Play Billing, and crash/analytics tooling.

## 5. Data Retention & Deletion
You can request deletion of your account and associated data at any time from
**Profile → Delete Account**. Deletion removes your personal data from our active systems,
subject to standard backup retention windows described at [RETENTION PERIOD].

## 6. Your Rights
Depending on your jurisdiction, you may have rights to access, correct, export, or delete your
personal data. Contact us at **[SUPPORT EMAIL]** to exercise these rights.

## 7. Children's Privacy
Livo AI is not directed at children under 13 (or the minimum age required in your region).

## 8. Contact
Questions about this Privacy Policy: **[SUPPORT EMAIL]**.
