package com.muhammadsamirkhankabir.livoai.navigation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.ads.AdManager
import com.muhammadsamirkhankabir.livoai.billing.BillingManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import javax.inject.Inject

/**
 * Thin Hilt-scoped bridge that keeps [AdManager.isPremium] in sync with the
 * server-verified [BillingManager.isPremiumVerified] flow, so ads disappear the
 * moment a purchase is verified — never from a client-only flag.
 */
@HiltViewModel
class AdManagerHolder @Inject constructor(
    val adManager: AdManager,
    billingManager: BillingManager
) : ViewModel() {
    init {
        billingManager.isPremiumVerified
            .onEach { adManager.isPremium.value = it }
            .launchIn(viewModelScope)
        billingManager.startConnection { adManager.preloadRewardedAd() }
    }
}
