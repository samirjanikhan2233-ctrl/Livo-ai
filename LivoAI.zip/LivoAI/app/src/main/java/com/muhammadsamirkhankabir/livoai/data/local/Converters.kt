package com.muhammadsamirkhankabir.livoai.data.local

import androidx.room.TypeConverter
import com.muhammadsamirkhankabir.livoai.data.local.entities.*

class Converters {
    @TypeConverter fun fromPriority(v: Priority) = v.name
    @TypeConverter fun toPriority(v: String) = Priority.valueOf(v)

    @TypeConverter fun fromGoalCategory(v: GoalCategory) = v.name
    @TypeConverter fun toGoalCategory(v: String) = GoalCategory.valueOf(v)

    @TypeConverter fun fromTxType(v: TransactionType) = v.name
    @TypeConverter fun toTxType(v: String) = TransactionType.valueOf(v)

    @TypeConverter fun fromTxCategory(v: TransactionCategory) = v.name
    @TypeConverter fun toTxCategory(v: String) = TransactionCategory.valueOf(v)

    @TypeConverter fun fromChatRole(v: ChatRole) = v.name
    @TypeConverter fun toChatRole(v: String) = ChatRole.valueOf(v)
}
