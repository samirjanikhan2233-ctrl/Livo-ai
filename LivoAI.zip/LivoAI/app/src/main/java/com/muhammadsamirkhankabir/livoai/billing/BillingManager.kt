package com.muhammadsamirkhankabir.livoai.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import com.muhammadsamirkhankabir.livoai.data.remote.LivoBackendApi
import com.muhammadsamirkhankabir.livoai.data.remote.VerifyPurchaseDto
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

const val MONTHLY_SUB_ID = "livo_ai_premium_monthly"
const val YEARLY_SUB_ID = "livo_ai_premium_yearly"

data class PremiumOffer(
    val productId: String,
    val formattedPrice: String,
    val billingPeriod: String,
    val offerToken: String
)

sealed class PurchaseUiState {
    data object Idle : PurchaseUiState()
    data object Loading : PurchaseUiState()
    data object Success : PurchaseUiState()
    data class Error(val message: String) : PurchaseUiState()
}

/**
 * Real Google Play Billing Library v7 integration.
 *
 * IMPORTANT — security model:
 *  - A successful `onPurchasesUpdated` callback means Play accepted the purchase
 *    locally; it does NOT by itself grant premium.
 *  - We always send the purchase token to OUR backend (`verifyPurchase`), which
 *    calls the Google Play Developer API server-side (using PAYMENT_CONFIG /
 *    service-account credentials that never touch the client) to confirm the
 *    purchase is genuine, unexpired and unacknowledged-but-valid.
 *  - Only the backend's response updates `isPremiumVerified`. The app never sets
 *    `isPremium = true` from a client-only signal.
 */
@Singleton
class BillingManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val api: LivoBackendApi
) : PurchasesUpdatedListener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val purchaseState = MutableStateFlow<PurchaseUiState>(PurchaseUiState.Idle)
    val isPremiumVerified = MutableStateFlow(false)
    val availableOffers = MutableStateFlow<List<PremiumOffer>>(emptyList())

    private val billingClient: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
        )
        .build()

    fun startConnection(onReady: () -> Unit = {}) {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts()
                    restorePurchases()
                    onReady()
                }
            }
            override fun onBillingServiceDisconnected() {
                // Billing library retries internally; UI should show a retry action on purchase.
            }
        })
    }

    private fun queryProducts() {
        val products = listOf(MONTHLY_SUB_ID, YEARLY_SUB_ID).map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        }
        val params = QueryProductDetailsParams.newBuilder().setProductList(products).build()
        billingClient.queryProductDetailsAsync(params) { result, productDetailsResult ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                val offers = productDetailsResult.productDetailsList.mapNotNull { details ->
                    val offer = details.subscriptionOfferDetails?.firstOrNull() ?: return@mapNotNull null
                    val phase = offer.pricingPhases.pricingPhaseList.firstOrNull() ?: return@mapNotNull null
                    PremiumOffer(
                        productId = details.productId,
                        formattedPrice = phase.formattedPrice,
                        billingPeriod = phase.billingPeriod,
                        offerToken = offer.offerToken
                    )
                }
                availableOffers.value = offers
                _productDetailsCache = productDetailsResult.productDetailsList
            }
        }
    }

    private var _productDetailsCache: List<ProductDetails> = emptyList()

    fun launchPurchaseFlow(activity: Activity, productId: String) {
        val details = _productDetailsCache.find { it.productId == productId } ?: run {
            purchaseState.value = PurchaseUiState.Error("Offer not available yet. Please try again.")
            return
        }
        val offerToken = details.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: return
        val productParams = listOf(
            BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(details)
                .setOfferToken(offerToken)
                .build()
        )
        val flowParams = BillingFlowParams.newBuilder().setProductDetailsParamsList(productParams).build()
        purchaseState.value = PurchaseUiState.Loading
        billingClient.launchBillingFlow(activity, flowParams)
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                purchases?.forEach { verifyAndAcknowledge(it) }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> {
                purchaseState.value = PurchaseUiState.Idle
            }
            else -> {
                purchaseState.value = PurchaseUiState.Error(result.debugMessage.ifBlank { "Purchase failed." })
            }
        }
    }

    fun restorePurchases() {
        val params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        billingClient.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                if (purchases.isEmpty()) {
                    scope.launch { isPremiumVerified.value = false }
                } else {
                    purchases.forEach { verifyAndAcknowledge(it) }
                }
            }
        }
    }

    private fun verifyAndAcknowledge(purchase: Purchase) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return

        scope.launch {
            try {
                // Server-side truth: never trust the client's own purchase object alone.
                val status = api.verifyPurchase(
                    VerifyPurchaseDto(
                        purchaseToken = purchase.purchaseToken,
                        productId = purchase.products.firstOrNull().orEmpty(),
                        isSubscription = true
                    )
                )
                isPremiumVerified.value = status.isPremium
                purchaseState.value = if (status.isPremium) PurchaseUiState.Success
                    else PurchaseUiState.Error("Purchase could not be verified. Contact support if you were charged.")

                if (status.isPremium && !purchase.isAcknowledged) {
                    val ackParams = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.purchaseToken).build()
                    billingClient.acknowledgePurchase(ackParams) {}
                }
            } catch (e: Exception) {
                purchaseState.value = PurchaseUiState.Error("Could not reach Livo AI servers to verify your purchase. It will retry automatically.")
            }
        }
    }

    suspend fun refreshEntitlementFromServer() {
        try {
            val status = api.getSubscriptionStatus()
            isPremiumVerified.value = status.isPremium
        } catch (_: Exception) {
            // Keep last known state; UI shows offline banner elsewhere.
        }
    }
}
