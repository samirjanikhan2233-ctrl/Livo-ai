package com.muhammadsamirkhankabir.livoai.ui.screens.planner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.ads.AdManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.Priority
import com.muhammadsamirkhankabir.livoai.data.local.entities.TaskEntity
import com.muhammadsamirkhankabir.livoai.ui.components.BannerAdSlot

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    onAddTask: () -> Unit,
    onEditTask: (String) -> Unit,
    adManager: AdManager,
    viewModel: TaskViewModel = hiltViewModel()
) {
    val filter by viewModel.filter.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val tasks by viewModel.filteredTasks.collectAsState()
    var showSearch by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Planner") },
                actions = { IconButton(onClick = { showSearch = !showSearch }) { Icon(Icons.Filled.Search, contentDescription = "Search") } }
            )
        },
        floatingActionButton = { FloatingActionButton(onClick = onAddTask) { Icon(Icons.Filled.Add, contentDescription = "Add task") } }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (showSearch) {
                OutlinedTextField(
                    value = query, onValueChange = { viewModel.searchQuery.value = it },
                    label = { Text("Search tasks") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            ScrollableTabRow(selectedTabIndex = TaskFilter.entries.indexOf(filter), edgePadding = 16.dp) {
                TaskFilter.entries.forEach { f ->
                    Tab(
                        selected = filter == f,
                        onClick = { viewModel.filter.value = f },
                        text = { Text(f.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            if (tasks.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No tasks here yet. Tap + to add one.", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
                    items(tasks, key = { it.id }) { task ->
                        TaskRow(task, onToggle = { viewModel.toggleComplete(task) }, onClick = { onEditTask(task.id) }, onDelete = { viewModel.delete(task.id) })
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
            BannerAdSlot(adManager)
        }
    }
}

@Composable
private fun TaskRow(task: TaskEntity, onToggle: () -> Unit, onClick: () -> Unit, onDelete: () -> Unit) {
    val priorityColor = when (task.priority) {
        Priority.HIGH -> Color(0xFFE5484D)
        Priority.MEDIUM -> Color(0xFFF5A623)
        Priority.LOW -> Color(0xFF30A46C)
    }
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = task.isCompleted, onCheckedChange = { onToggle() })
            Box(Modifier.width(4.dp).height(32.dp).background(priorityColor))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    task.title,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )
                if (task.notes.isNotBlank()) Text(task.notes, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
        }
    }
}

private fun Modifier.background(color: Color) = this.then(androidx.compose.foundation.background(color))
