package com.muhammadsamirkhankabir.livoai.ui.theme

import androidx.compose.ui.graphics.Color

val LivoPrimary = Color(0xFF5B5BF7)
val LivoPrimaryDark = Color(0xFF3E3ED6)
val LivoSecondary = Color(0xFF00C2A8)
val LivoBackgroundLight = Color(0xFFFAFAFF)
val LivoBackgroundDark = Color(0xFF0F0F1A)
val LivoSurfaceLight = Color(0xFFFFFFFF)
val LivoSurfaceDark = Color(0xFF1A1A2E)
val LivoError = Color(0xFFE5484D)
val LivoSuccess = Color(0xFF30A46C)
val LivoWarning = Color(0xFFF5A623)
val LivoOnPrimary = Color(0xFFFFFFFF)
val LivoTextLight = Color(0xFF16161F)
val LivoTextDark = Color(0xFFF2F2F7)
