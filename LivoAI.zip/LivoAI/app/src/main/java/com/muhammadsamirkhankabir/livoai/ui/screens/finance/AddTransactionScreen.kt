package com.muhammadsamirkhankabir.livoai.ui.screens.finance

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.data.local.entities.TransactionCategory
import com.muhammadsamirkhankabir.livoai.data.local.entities.TransactionType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionScreen(onDone: () -> Unit, onBack: () -> Unit, viewModel: FinanceViewModel = hiltViewModel()) {
    var type by remember { mutableStateOf(TransactionType.EXPENSE) }
    var category by remember { mutableStateOf(TransactionCategory.FOOD) }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Add transaction") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = type == TransactionType.EXPENSE, onClick = { type = TransactionType.EXPENSE; category = TransactionCategory.FOOD }, label = { Text("Expense") })
                FilterChip(selected = type == TransactionType.INCOME, onClick = { type = TransactionType.INCOME; category = TransactionCategory.INCOME }, label = { Text("Income") })
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Amount") }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))

            if (type == TransactionType.EXPENSE) {
                Text("Category", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                FlowCategoryPicker(category) { category = it }
                Spacer(Modifier.height(16.dp))
            }

            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount > 0) { viewModel.addTransaction(type, category, amount, note); onDone() }
                },
                enabled = amountText.toDoubleOrNull() != null,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Save") }
        }
    }
}

@Composable
private fun FlowCategoryPicker(selected: TransactionCategory, onSelect: (TransactionCategory) -> Unit) {
    val categories = TransactionCategory.entries.filter { it != TransactionCategory.INCOME }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        categories.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { cat ->
                    FilterChip(selected = selected == cat, onClick = { onSelect(cat) }, label = { Text(cat.name.lowercase().replaceFirstChar { it.uppercase() }) })
                }
            }
        }
    }
}
