package com.muhammadsamirkhankabir.livoai.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Priority { LOW, MEDIUM, HIGH }

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val notes: String = "",
    val priority: Priority = Priority.MEDIUM,
    val dueDateEpochDay: Long,       // date the task is scheduled for
    val dueTimeMinutes: Int? = null, // minutes since midnight, null = no specific time
    val isCompleted: Boolean = false,
    val completedAtEpochMillis: Long? = null,
    val isRecurring: Boolean = false,
    val recurrenceRule: String? = null, // e.g. "DAILY", "WEEKLY:MON,WED,FRI"
    val reminderEnabled: Boolean = false,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
    val isSynced: Boolean = false,   // false = pending upload to backend (offline support)
    val isDeleted: Boolean = false   // soft delete for sync
)
