package com.muhammadsamirkhankabir.livoai.ui.screens.ai

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatMessageEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatRole
import com.muhammadsamirkhankabir.livoai.ads.AdManager
import com.muhammadsamirkhankabir.livoai.ui.components.BannerAdSlot
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(adManager: AdManager, viewModel: ChatViewModel = hiltViewModel()) {
    val conversations by viewModel.conversations.collectAsState()
    val activeId by viewModel.activeConversationId.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isSending by viewModel.isSending.collectAsState()
    val error by viewModel.errorMessage.collectAsState()

    var input by remember { mutableStateOf("") }
    var showHistory by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) scope.launch { listState.animateScrollToItem(messages.size - 1) } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ask Livo AI") },
                navigationIcon = { IconButton(onClick = { showHistory = true }) { Icon(Icons.Filled.Menu, contentDescription = "Chat history") } },
                actions = { IconButton(onClick = { viewModel.startNewChat() }) { Icon(Icons.Filled.Add, contentDescription = "New chat") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (messages.isEmpty()) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
                    Text("Try asking:", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    SUGGESTED_PROMPTS.forEach { prompt ->
                        OutlinedButton(onClick = { viewModel.send(prompt) }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text(prompt)
                        }
                    }
                }
            } else {
                LazyColumn(state = listState, modifier = Modifier.weight(1f), contentPadding = PaddingValues(16.dp)) {
                    items(messages, key = { it.id }) { msg ->
                        ChatBubble(
                            msg,
                            onCopy = { clipboard.setText(AnnotatedString(msg.content)) },
                            onRegenerate = if (msg.role == ChatRole.ASSISTANT && msg == messages.lastOrNull { it.role == ChatRole.ASSISTANT })
                                { { viewModel.regenerate() } } else null
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    if (isSending) item { TypingIndicator() }
                }
            }

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)
            }

            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("Message Livo AI…") },
                    modifier = Modifier.weight(1f), maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = { if (input.isNotBlank()) { viewModel.send(input); input = "" } },
                    enabled = !isSending
                ) { Icon(Icons.Filled.Send, contentDescription = "Send") }
            }
            BannerAdSlot(adManager)
        }
    }

    if (showHistory) {
        ModalBottomSheet(onDismissRequest = { showHistory = false }) {
            Column(Modifier.padding(16.dp)) {
                Text("Chat history", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                if (conversations.isEmpty()) Text("No conversations yet.")
                conversations.forEach { convo ->
                    Row(
                        Modifier.fillMaxWidth()
                            .combinedClickable(onClick = { viewModel.openConversation(convo.id); showHistory = false })
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(convo.title, maxLines = 1)
                        IconButton(onClick = { viewModel.deleteConversation(convo.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete chat")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessageEntity, onCopy: () -> Unit, onRegenerate: (() -> Unit)?) {
    val isUser = message.role == ChatRole.USER
    Column(horizontalAlignment = if (isUser) Alignment.End else Alignment.Start, modifier = Modifier.fillMaxWidth()) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primary else if (message.isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
        ) {
            Text(
                message.content,
                modifier = Modifier.padding(12.dp),
                color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (!isUser) {
            Row {
                TextButton(onClick = onCopy) { Text("Copy", style = MaterialTheme.typography.labelSmall) }
                onRegenerate?.let { TextButton(onClick = it) { Text("Regenerate", style = MaterialTheme.typography.labelSmall) } }
            }
        }
    }
}

@Composable
private fun TypingIndicator() {
    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
        Spacer(Modifier.width(8.dp))
        Text("Livo AI is thinking…", style = MaterialTheme.typography.bodySmall)
    }
}
