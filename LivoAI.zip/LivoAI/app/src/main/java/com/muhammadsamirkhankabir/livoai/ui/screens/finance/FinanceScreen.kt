package com.muhammadsamirkhankabir.livoai.ui.screens.finance

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.ads.AdManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.TransactionEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.TransactionType
import com.muhammadsamirkhankabir.livoai.ui.components.BannerAdSlot

@Composable
fun FinanceScreen(
    onAddTransaction: () -> Unit,
    onOpenBudget: () -> Unit,
    adManager: AdManager,
    viewModel: FinanceViewModel = hiltViewModel()
) {
    val summary by viewModel.summary.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val budget by viewModel.budget.collectAsState()
    val insight by viewModel.aiInsight.collectAsState()
    val insightLoading by viewModel.aiInsightLoading.collectAsState()
    var showAskAi by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Finance") }) },
        floatingActionButton = { FloatingActionButton(onClick = onAddTransaction) { Icon(Icons.Filled.Add, contentDescription = "Add transaction") } }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SummaryCard(Modifier.weight(1f), "Income", summary.totalIncome, Color(0xFF30A46C))
                        SummaryCard(Modifier.weight(1f), "Expenses", summary.totalExpenses, Color(0xFFE5484D))
                    }
                    Spacer(Modifier.height(12.dp))
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Balance", style = MaterialTheme.typography.titleMedium)
                            Text("$${"%.2f".format(summary.balance)}", style = MaterialTheme.typography.headlineMedium)
                        }
                    }
                    Spacer(Modifier.height(12.dp))

                    budget?.let { b ->
                        val remaining = b.monthlyLimit - summary.totalExpenses
                        ElevatedCard(Modifier.fillMaxWidth().clickableOnce(onOpenBudget)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Monthly budget", style = MaterialTheme.typography.titleMedium)
                                LinearProgressIndicator(
                                    progress = { (summary.totalExpenses / b.monthlyLimit).toFloat().coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(8.dp)
                                )
                                Text("Spent $${"%.0f".format(summary.totalExpenses)} of $${"%.0f".format(b.monthlyLimit)}  •  Remaining $${"%.0f".format(remaining)}")
                            }
                        }
                    } ?: OutlinedButton(onClick = onOpenBudget, modifier = Modifier.fillMaxWidth()) { Text("Set a monthly budget") }

                    Spacer(Modifier.height(12.dp))
                    if (summary.categoryBreakdown.isNotEmpty()) {
                        Text("Category breakdown", style = MaterialTheme.typography.titleMedium)
                        summary.categoryBreakdown.entries.sortedByDescending { it.value }.forEach { (cat, amount) ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(cat.lowercase().replaceFirstChar { it.uppercase() })
                                Text("$${"%.2f".format(amount)}")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }

                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Ask AI about your finances", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Informational only — not professional financial advice.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AssistChip(onClick = { viewModel.askAiAboutFinances("Where am I spending the most?") }, label = { Text("Where am I spending most?") })
                            }
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AssistChip(onClick = { viewModel.askAiAboutFinances("Help me create a monthly budget.") }, label = { Text("Help me budget") })
                            }
                            if (insightLoading) {
                                Spacer(Modifier.height(8.dp))
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            }
                            insight?.let {
                                Spacer(Modifier.height(8.dp))
                                Text(it, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Transaction history", style = MaterialTheme.typography.titleMedium)
                }
                items(transactions, key = { it.id }) { tx -> TransactionRow(tx) }
                item { Spacer(Modifier.height(80.dp)) }
            }
            BannerAdSlot(adManager)
        }
    }
}

@Composable
private fun SummaryCard(modifier: Modifier, label: String, amount: Double, color: Color) {
    ElevatedCard(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("$${"%.2f".format(amount)}", style = MaterialTheme.typography.titleLarge, color = color)
        }
    }
}

@Composable
private fun TransactionRow(tx: TransactionEntity) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(tx.category.name.lowercase().replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.bodyLarge)
            if (tx.note.isNotBlank()) Text(tx.note, style = MaterialTheme.typography.bodySmall)
        }
        Text(
            (if (tx.type == TransactionType.EXPENSE) "-" else "+") + "$${"%.2f".format(tx.amount)}",
            color = if (tx.type == TransactionType.EXPENSE) Color(0xFFE5484D) else Color(0xFF30A46C)
        )
    }
}

private fun Modifier.clickableOnce(onClick: () -> Unit) =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
