package com.muhammadsamirkhankabir.livoai.auth

import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Wraps Firebase Auth. Passwords are never handled or stored by this app directly —
 * Firebase Auth performs secure hashing/storage server-side. This class exposes only
 * what the ID token and user id, which the backend re-verifies on every request.
 */
@Singleton
class SessionManager @Inject constructor(
    private val firebaseAuth: FirebaseAuth
) {
    // Kept fresh by the listener below; used for the synchronous OkHttp interceptor.
    // The backend independently re-verifies every token on every request, so a
    // momentarily-stale cached token here only ever fails closed, never open.
    @Volatile private var cachedIdToken: String? = null

    init {
        firebaseAuth.addIdTokenListener { auth ->
            auth.currentUser?.getIdToken(false)
                ?.addOnSuccessListener { cachedIdToken = it.token }
                ?: run { cachedIdToken = null }
        }
    }

    val currentUserId: String? get() = firebaseAuth.currentUser?.uid
    val currentUserEmail: String? get() = firebaseAuth.currentUser?.email
    val currentUserName: String? get() = firebaseAuth.currentUser?.displayName

    fun isLoggedIn(): Boolean = firebaseAuth.currentUser != null

    suspend fun currentIdToken(forceRefresh: Boolean = false): String? =
        firebaseAuth.currentUser?.getIdToken(forceRefresh)?.await()?.token?.also { cachedIdToken = it }

    /** Synchronous, best-effort token for the OkHttp interceptor. */
    fun currentIdTokenBlocking(): String? = cachedIdToken

    fun logout() = firebaseAuth.signOut()
}
