package com.muhammadsamirkhankabir.livoai.ui.screens.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatConversationEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatMessageEntity
import com.muhammadsamirkhankabir.livoai.data.repository.AiChatResult
import com.muhammadsamirkhankabir.livoai.data.repository.ChatRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

val SUGGESTED_PROMPTS = listOf(
    "Plan my day",
    "Help me save money",
    "Create a study plan",
    "Help me reach my goal",
    "Give me productivity ideas"
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: ChatRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val userId get() = sessionManager.currentUserId.orEmpty()

    val conversations: StateFlow<List<ChatConversationEntity>> =
        repository.observeConversations(userId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeConversationId = MutableStateFlow<String?>(null)
    val isSending = MutableStateFlow(false)
    val errorMessage = MutableStateFlow<String?>(null)

    val messages: StateFlow<List<ChatMessageEntity>> = activeConversationId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.observeMessages(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun startNewChat() = viewModelScope.launch {
        val id = repository.newConversation(userId)
        activeConversationId.value = id
    }

    fun openConversation(id: String) { activeConversationId.value = id }

    fun deleteConversation(id: String) = viewModelScope.launch {
        repository.deleteConversation(id)
        if (activeConversationId.value == id) activeConversationId.value = null
    }

    fun send(text: String) {
        if (text.isBlank()) return
        val convoId = activeConversationId.value
        viewModelScope.launch {
            isSending.value = true
            errorMessage.value = null
            val id = convoId ?: repository.newConversation(userId, text.take(40)).also { activeConversationId.value = it }
            when (val result = repository.sendMessage(id, userId, text)) {
                is AiChatResult.Success -> {}
                is AiChatResult.RateLimited -> errorMessage.value = result.message
                is AiChatResult.NetworkError -> errorMessage.value = result.message
                is AiChatResult.ServerError -> errorMessage.value = result.message
            }
            isSending.value = false
        }
    }

    fun regenerate() {
        val id = activeConversationId.value ?: return
        viewModelScope.launch {
            isSending.value = true
            when (val result = repository.regenerateLast(id, userId)) {
                is AiChatResult.Success -> {}
                is AiChatResult.RateLimited -> errorMessage.value = result.message
                is AiChatResult.NetworkError -> errorMessage.value = result.message
                is AiChatResult.ServerError -> errorMessage.value = result.message
            }
            isSending.value = false
        }
    }
}
