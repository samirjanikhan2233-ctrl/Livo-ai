package com.muhammadsamirkhankabir.livoai.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String, // stable code, e.g. "FIRST_TASK"
    val userId: String,
    val title: String,
    val description: String,
    val icon: String,
    val isUnlocked: Boolean = false,
    val unlockedAtEpochMillis: Long? = null
)

@Entity(tableName = "user_progress")
data class UserProgressEntity(
    @PrimaryKey val userId: String,
    val xp: Int = 0,
    val level: Int = 1
)
