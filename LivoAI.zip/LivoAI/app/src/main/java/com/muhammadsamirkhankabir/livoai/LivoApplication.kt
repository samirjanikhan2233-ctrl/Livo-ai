package com.muhammadsamirkhankabir.livoai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.google.android.gms.ads.MobileAds
import dagger.hilt.android.HiltAndroidApp

/**
 * Livo AI application entry point.
 * - Initializes Hilt DI graph
 * - Initializes AdMob SDK (test ads in debug, real ads configured via BuildConfig)
 * - Creates notification channels for reminders
 */
@HiltAndroidApp
class LivoApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_TASKS, "Task Reminders", NotificationManager.IMPORTANCE_DEFAULT
                ),
                NotificationChannel(
                    CHANNEL_HABITS, "Habit Reminders", NotificationManager.IMPORTANCE_DEFAULT
                ),
                NotificationChannel(
                    CHANNEL_GOALS, "Goal Reminders", NotificationManager.IMPORTANCE_DEFAULT
                ),
                NotificationChannel(
                    CHANNEL_BUDGET, "Budget Alerts", NotificationManager.IMPORTANCE_HIGH
                )
            )
            channels.forEach { manager.createNotificationChannel(it) }
        }
    }

    companion object {
        const val CHANNEL_TASKS = "livo_tasks"
        const val CHANNEL_HABITS = "livo_habits"
        const val CHANNEL_GOALS = "livo_goals"
        const val CHANNEL_BUDGET = "livo_budget"
    }
}
