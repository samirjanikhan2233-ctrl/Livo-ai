package com.muhammadsamirkhankabir.livoai.ui.screens.legal

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.muhammadsamirkhankabir.livoai.BuildConfig
import com.muhammadsamirkhankabir.livoai.util.Constants

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LegalScaffold(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) { content() }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    LegalScaffold("About", onBack) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text("Livo AI", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Developed by MuhammadSamirKhankabir", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text("Version ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})", style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "Livo AI is an all-in-one AI personal assistant and productivity app: chat with AI, plan your day, " +
                "track habits, set goals, manage your finances, take notes, and earn XP along the way."
        )
    }
}

/**
 * These placeholder documents fulfil the "Create a Privacy Policy / Terms page" requirement
 * with structurally complete, real legal-document sections. Replace the bracketed placeholders
 * with your actual company/contact details before publishing — do not publish placeholder text.
 */
@Composable
fun PrivacyPolicyScreen(onBack: () -> Unit) {
    LegalScaffold("Privacy Policy", onBack) {
        Text("Privacy Policy for Livo AI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Last updated: [DATE]", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        LegalSection("1. Information We Collect", "Account information (name, email), content you create (tasks, habits, goals, notes, finance entries), AI conversation history, and device/usage data necessary to operate the app.")
        LegalSection("2. How We Use Information", "To provide and improve Livo AI's features, to personalize AI responses, to process Premium subscriptions via Google Play Billing, and to send reminders you've enabled.")
        LegalSection("3. AI Processing", "Messages you send to the AI Assistant are processed by our backend and a third-party AI provider in order to generate a response. We do not use your private financial or note data to train AI models without your consent.")
        LegalSection("4. Data Sharing", "We do not sell your personal data. We share data only with service providers necessary to run the app (hosting, AI provider, Google Play Billing, analytics/crash reporting).")
        LegalSection("5. Data Retention & Deletion", "You can delete your account at any time from Profile > Delete Account. This removes your personal data from our systems, subject to standard backup retention windows.")
        LegalSection("6. Your Rights", "Depending on your location, you may have rights to access, correct, or delete your data. Contact us at [SUPPORT EMAIL] to exercise these rights.")
        LegalSection("7. Contact", "Questions about this policy can be sent to [SUPPORT EMAIL].")
        Spacer(Modifier.height(24.dp))
        Text("This is a placeholder document. Replace bracketed fields with your real information before publishing.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun TermsScreen(onBack: () -> Unit) {
    LegalScaffold("Terms & Conditions", onBack) {
        Text("Terms & Conditions for Livo AI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Last updated: [DATE]", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        LegalSection("1. Acceptance of Terms", "By using Livo AI, developed by MuhammadSamirKhankabir, you agree to these Terms & Conditions.")
        LegalSection("2. Use of the App", "Livo AI is provided for personal productivity use. You agree not to misuse the AI Assistant, attempt to extract other users' data, or reverse-engineer the app.")
        LegalSection("3. AI-Generated Content", "AI suggestions (daily plans, goal breakdowns, finance insights, note summaries) are provided for informational purposes only and are not professional financial, medical, or legal advice.")
        LegalSection("4. Subscriptions", "Premium subscriptions are billed through Google Play Billing on a monthly or yearly recurring basis until cancelled. Manage or cancel your subscription from the Google Play Store.")
        LegalSection("5. Account Termination", "You may delete your account at any time. We may suspend accounts that violate these terms.")
        LegalSection("6. Limitation of Liability", "Livo AI is provided \"as is\" without warranties of any kind, to the extent permitted by law.")
        LegalSection("7. Contact", "Questions about these terms can be sent to [SUPPORT EMAIL].")
        Spacer(Modifier.height(24.dp))
        Text("This is a placeholder document. Replace bracketed fields with your real information before publishing.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SupportScreen(onBack: () -> Unit) {
    LegalScaffold("Help & Support", onBack) {
        Text("Need help with Livo AI?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Email us at ${Constants.SUPPORT_EMAIL} and we'll get back to you as soon as possible.")
        Spacer(Modifier.height(20.dp))
        Text("Common topics:", fontWeight = FontWeight.SemiBold)
        Text("• Account & login issues")
        Text("• Restoring a Premium purchase")
        Text("• Reporting a bug")
        Text("• Requesting account/data deletion")
    }
}

@Composable
private fun LegalSection(title: String, body: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    Text(body, style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(12.dp))
}
