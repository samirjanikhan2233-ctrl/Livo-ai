package com.muhammadsamirkhankabir.livoai.data.repository

import com.muhammadsamirkhankabir.livoai.data.local.dao.NoteDao
import com.muhammadsamirkhankabir.livoai.data.local.entities.NoteEntity
import com.muhammadsamirkhankabir.livoai.data.remote.LivoBackendApi
import com.muhammadsamirkhankabir.livoai.data.remote.SummarizeRequestDto
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NoteRepository @Inject constructor(
    private val dao: NoteDao,
    private val api: LivoBackendApi
) {
    fun observeNotes(userId: String) = dao.observeNotes(userId)
    fun search(userId: String, query: String) = dao.search(userId, query)

    suspend fun createOrUpdate(note: NoteEntity): NoteEntity {
        val toSave = note.copy(
            id = note.id.ifBlank { UUID.randomUUID().toString() },
            updatedAtEpochMillis = System.currentTimeMillis(),
            isSynced = false
        )
        dao.upsert(toSave)
        return toSave
    }

    suspend fun delete(id: String) = dao.softDelete(id)

    suspend fun togglePin(note: NoteEntity) = dao.upsert(note.copy(isPinned = !note.isPinned, isSynced = false))

    suspend fun toggleArchive(note: NoteEntity) = dao.upsert(note.copy(isArchived = !note.isArchived, isSynced = false))

    /** Real backend call — the user explicitly taps "Summarize with AI" (confirmation-gated in the UI). */
    suspend fun summarizeWithAi(note: NoteEntity): Result<String> = try {
        val response = api.summarizeNote(SummarizeRequestDto(note.content))
        dao.upsert(note.copy(aiSummary = response.summary, isSynced = false))
        Result.success(response.summary)
    } catch (e: Exception) {
        Result.failure(e)
    }
}
