package com.muhammadsamirkhankabir.livoai.data.repository

import com.muhammadsamirkhankabir.livoai.data.local.dao.GamificationDao
import com.muhammadsamirkhankabir.livoai.data.local.entities.UserProgressEntity
import com.muhammadsamirkhankabir.livoai.gamification.XpManager
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GamificationRepository @Inject constructor(
    private val dao: GamificationDao,
    private val xpManager: XpManager
) {
    fun observeProgress(userId: String) = dao.observeProgress(userId)
    fun observeAchievements(userId: String) = dao.observeAchievements(userId)

    /** Only seeds a fresh XP=0/level=1 row and default achievements for a brand-new user. */
    suspend fun ensureInitialized(userId: String) {
        val existing = dao.observeProgress(userId).first()
        if (existing == null) {
            dao.upsertProgress(UserProgressEntity(userId, 0, 1))
        }
        xpManager.seedDefaultAchievements(userId) // safe: INSERT ... IGNORE, won't overwrite unlocked ones
    }
}
