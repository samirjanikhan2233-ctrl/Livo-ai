package com.muhammadsamirkhankabir.livoai.ui.screens.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.NoteEntity
import com.muhammadsamirkhankabir.livoai.data.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NoteViewModel @Inject constructor(
    private val repository: NoteRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val userId get() = sessionManager.currentUserId.orEmpty()
    val searchQuery = MutableStateFlow("")
    val summarizing = MutableStateFlow<String?>(null) // noteId currently summarizing

    val notes: StateFlow<List<NoteEntity>> = searchQuery.flatMapLatest { q ->
        if (q.isBlank()) repository.observeNotes(userId) else repository.search(userId, q)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun save(existing: NoteEntity?, title: String, content: String, category: String) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        repository.createOrUpdate(
            existing?.copy(title = title, content = content, category = category)
                ?: NoteEntity(id = "", userId = userId, title = title, content = content, category = category, createdAtEpochMillis = now, updatedAtEpochMillis = now)
        )
    }

    fun delete(id: String) = viewModelScope.launch { repository.delete(id) }
    fun togglePin(note: NoteEntity) = viewModelScope.launch { repository.togglePin(note) }
    fun toggleArchive(note: NoteEntity) = viewModelScope.launch { repository.toggleArchive(note) }

    /** Called only after the user confirms in a dialog — see NotesScreen. */
    fun summarizeConfirmed(note: NoteEntity) = viewModelScope.launch {
        summarizing.value = note.id
        repository.summarizeWithAi(note)
        summarizing.value = null
    }
}
