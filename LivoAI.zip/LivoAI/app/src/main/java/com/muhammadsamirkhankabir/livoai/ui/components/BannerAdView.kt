package com.muhammadsamirkhankabir.livoai.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.muhammadsamirkhankabir.livoai.ads.AdManager

/**
 * A single reusable banner slot. Placed at the bottom of scrollable screens,
 * BELOW the bottom navigation bar's tap targets — never overlapping a button,
 * per AdMob placement policy. Renders nothing at all for Premium users.
 */
@Composable
fun BannerAdSlot(adManager: AdManager, modifier: Modifier = Modifier) {
    val isPremium by adManager.isPremium.collectAsState()
    if (isPremium) return // Premium users get an ad-free experience.

    val context = LocalContext.current
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = {
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = adManager.bannerAdUnitId
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
