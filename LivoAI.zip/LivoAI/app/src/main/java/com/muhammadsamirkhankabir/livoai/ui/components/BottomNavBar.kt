package com.muhammadsamirkhankabir.livoai.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.currentBackStackEntryAsState
import com.muhammadsamirkhankabir.livoai.navigation.Destinations

private data class NavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val items = listOf(
    NavItem(Destinations.HOME, "Home", Icons.Filled.Home),
    NavItem(Destinations.PLANNER, "Planner", Icons.Filled.CheckCircle),
    NavItem(Destinations.HABITS, "Habits", Icons.Filled.Loop),
    NavItem(Destinations.FINANCE, "Finance", Icons.Filled.AccountBalanceWallet),
    NavItem(Destinations.AI_CHAT, "AI", Icons.Filled.AutoAwesome),
)

@Composable
fun LivoBottomNavBar(navController: NavController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination

    NavigationBar {
        items.forEach { item ->
            val selected = currentRoute?.hierarchy?.any { it.route == item.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) }
            )
        }
    }
}

private fun androidx.navigation.NavGraph.findStartDestination() =
    findNode(startDestinationId) ?: throw IllegalStateException("No start destination")
