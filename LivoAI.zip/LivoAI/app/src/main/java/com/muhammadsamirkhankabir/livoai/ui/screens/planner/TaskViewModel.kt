package com.muhammadsamirkhankabir.livoai.ui.screens.planner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.Priority
import com.muhammadsamirkhankabir.livoai.data.local.entities.TaskEntity
import com.muhammadsamirkhankabir.livoai.data.repository.TaskRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

enum class TaskFilter { TODAY, TOMORROW, THIS_WEEK, COMPLETED }

@HiltViewModel
class TaskViewModel @Inject constructor(
    private val repository: TaskRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val userId get() = sessionManager.currentUserId.orEmpty()

    val filter = MutableStateFlow(TaskFilter.TODAY)
    val searchQuery = MutableStateFlow("")

    private val allTasks = repository.observeTasks(userId)

    val filteredTasks: StateFlow<List<TaskEntity>> = combine(allTasks, filter, searchQuery) { tasks, f, query ->
        val today = LocalDate.now().toEpochDay()
        val tomorrow = today + 1
        val weekEnd = today + 7
        val byFilter = when (f) {
            TaskFilter.TODAY -> tasks.filter { it.dueDateEpochDay == today && !it.isCompleted }
            TaskFilter.TOMORROW -> tasks.filter { it.dueDateEpochDay == tomorrow && !it.isCompleted }
            TaskFilter.THIS_WEEK -> tasks.filter { it.dueDateEpochDay in today..weekEnd && !it.isCompleted }
            TaskFilter.COMPLETED -> tasks.filter { it.isCompleted }
        }
        if (query.isBlank()) byFilter else byFilter.filter { it.title.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleComplete(task: TaskEntity) = viewModelScope.launch { repository.toggleComplete(task, userId) }
    fun delete(id: String) = viewModelScope.launch { repository.deleteTask(id) }

    fun save(
        existing: TaskEntity?,
        title: String, notes: String, priority: Priority,
        dueDateEpochDay: Long, dueTimeMinutes: Int?,
        isRecurring: Boolean, recurrenceRule: String?, reminderEnabled: Boolean
    ) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        if (existing == null) {
            repository.createTask(
                TaskEntity(
                    id = "", userId = userId, title = title, notes = notes, priority = priority,
                    dueDateEpochDay = dueDateEpochDay, dueTimeMinutes = dueTimeMinutes,
                    isRecurring = isRecurring, recurrenceRule = recurrenceRule,
                    reminderEnabled = reminderEnabled, createdAtEpochMillis = now, updatedAtEpochMillis = now
                )
            )
        } else {
            repository.updateTask(
                existing.copy(
                    title = title, notes = notes, priority = priority,
                    dueDateEpochDay = dueDateEpochDay, dueTimeMinutes = dueTimeMinutes,
                    isRecurring = isRecurring, recurrenceRule = recurrenceRule, reminderEnabled = reminderEnabled
                )
            )
        }
    }
}
