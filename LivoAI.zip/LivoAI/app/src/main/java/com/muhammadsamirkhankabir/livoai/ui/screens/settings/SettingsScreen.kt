package com.muhammadsamirkhankabir.livoai.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.AuthRepository
import com.muhammadsamirkhankabir.livoai.util.Constants
import com.muhammadsamirkhankabir.livoai.util.SettingsStore
import com.muhammadsamirkhankabir.livoai.util.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsStore: SettingsStore,
    private val authRepository: AuthRepository
) : ViewModel() {
    val themeMode = settingsStore.themeMode
    fun setTheme(mode: ThemeMode) = viewModelScope.launch { settingsStore.setThemeMode(mode) }
    fun logout() = authRepository.logout()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenTerms: () -> Unit,
    onOpenSupport: () -> Unit,
    onLoggedOut: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val themeMode by viewModel.themeMode.collectAsState()

    Scaffold(topBar = {
        TopAppBar(title = { Text("Settings") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            SettingsSection("Appearance") {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(selected = themeMode == mode, onClick = { viewModel.setTheme(mode) }, label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) })
                    }
                }
            }
            SettingsSection("Notifications") {
                SettingsRow("Task reminders", Icons.Filled.NotificationsActive) {}
                SettingsRow("Habit reminders", Icons.Filled.NotificationsActive) {}
                SettingsRow("Goal reminders", Icons.Filled.NotificationsActive) {}
                SettingsRow("Budget alerts", Icons.Filled.NotificationsActive) {}
            }
            SettingsSection("About") {
                SettingsRow("About Livo AI", Icons.Filled.Info, onOpenAbout)
                SettingsRow("Privacy Policy", Icons.Filled.PrivacyTip, onOpenPrivacy)
                SettingsRow("Terms & Conditions", Icons.Filled.Description, onOpenTerms)
                SettingsRow("Help & Support", Icons.Filled.SupportAgent, onOpenSupport)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { viewModel.logout(); onLoggedOut() },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) { Text("Log out") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column {
        Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp))
        content()
        HorizontalDivider()
    }
}

@Composable
private fun SettingsRow(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickableRow(onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(16.dp))
        Text(label, modifier = Modifier.weight(1f))
        Icon(Icons.Filled.ChevronRight, contentDescription = null)
    }
}

private fun Modifier.clickableRow(onClick: () -> Unit) = this.then(androidx.compose.foundation.clickable(onClick = onClick))
