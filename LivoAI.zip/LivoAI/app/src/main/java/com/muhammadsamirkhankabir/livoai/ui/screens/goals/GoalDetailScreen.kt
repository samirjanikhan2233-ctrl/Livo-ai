package com.muhammadsamirkhankabir.livoai.ui.screens.goals

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalDetailScreen(goalId: String, onBack: () -> Unit, viewModel: GoalViewModel = hiltViewModel()) {
    val goals by viewModel.goals.collectAsState()
    val goal = goals.find { it.id == goalId } ?: return
    val milestones by viewModel.milestonesFor(goalId).collectAsState(initial = emptyList())
    val breakdownLoading by viewModel.breakdownLoading.collectAsState()
    val breakdownError by viewModel.breakdownError.collectAsState()
    var confirmBreakdown by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(title = { Text(goal.title) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Text(goal.description, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { goal.progressPercent / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp))
            Text("${goal.progressPercent}% complete")
            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Milestones", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { confirmBreakdown = true }, enabled = !breakdownLoading) {
                    if (breakdownLoading) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Text("AI Breakdown")
                }
            }
            breakdownError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

            milestones.forEach { m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = m.isCompleted, onCheckedChange = { viewModel.toggleMilestone(m, goal) })
                    Text(m.title)
                }
            }
        }
    }

    if (confirmBreakdown) {
        AlertDialog(
            onDismissRequest = { confirmBreakdown = false },
            title = { Text("Break this goal down with AI?") },
            text = { Text("Livo AI will suggest milestones for \"${goal.title}\", replacing your current milestone list.") },
            confirmButton = { TextButton(onClick = { viewModel.requestAiBreakdown(goal); confirmBreakdown = false }) { Text("Continue") } },
            dismissButton = { TextButton(onClick = { confirmBreakdown = false }) { Text("Cancel") } }
        )
    }
}
