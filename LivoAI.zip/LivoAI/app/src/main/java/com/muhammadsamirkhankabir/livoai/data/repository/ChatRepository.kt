package com.muhammadsamirkhankabir.livoai.data.repository

import com.muhammadsamirkhankabir.livoai.data.local.dao.ChatDao
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatConversationEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatMessageEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatRole
import com.muhammadsamirkhankabir.livoai.data.remote.ChatRequestDto
import com.muhammadsamirkhankabir.livoai.data.remote.ChatTurnDto
import com.muhammadsamirkhankabir.livoai.data.remote.LivoBackendApi
import kotlinx.coroutines.flow.first
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import retrofit2.HttpException
import java.io.IOException

sealed class AiChatResult {
    data class Success(val reply: String, val remainingMessagesToday: Int?) : AiChatResult()
    data class RateLimited(val message: String) : AiChatResult()
    data class NetworkError(val message: String) : AiChatResult()
    data class ServerError(val message: String) : AiChatResult()
}

/**
 * Real AI chat repository. The Android app never talks to an AI vendor directly —
 * every message is sent to Livo AI's own backend (LivoBackendApi), which holds the
 * real AI_API_KEY server-side. No response is ever hard-coded on-device.
 */
@Singleton
class ChatRepository @Inject constructor(
    private val dao: ChatDao,
    private val api: LivoBackendApi
) {
    fun observeConversations(userId: String) = dao.observeConversations(userId)
    fun observeMessages(conversationId: String) = dao.observeMessages(conversationId)

    suspend fun newConversation(userId: String, title: String = "New chat"): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        dao.upsertConversation(ChatConversationEntity(id, userId, title, now, now))
        return id
    }

    suspend fun deleteConversation(id: String) {
        dao.deleteConversation(id)
        dao.deleteMessagesFor(id)
    }

    suspend fun sendMessage(conversationId: String, userId: String, text: String): AiChatResult {
        val userMessage = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            role = ChatRole.USER,
            content = text,
            createdAtEpochMillis = System.currentTimeMillis()
        )
        dao.insertMessage(userMessage)

        val history = dao.observeMessages(conversationId).first().takeLast(20).map {
            ChatTurnDto(role = if (it.role == ChatRole.USER) "user" else "assistant", content = it.content)
        }

        return try {
            val response = api.sendChatMessage(ChatRequestDto(conversationId, text, history))
            dao.insertMessage(
                ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = conversationId,
                    role = ChatRole.ASSISTANT,
                    content = response.reply,
                    createdAtEpochMillis = System.currentTimeMillis()
                )
            )
            dao.upsertConversation(
                ChatConversationEntity(conversationId, userId, text.take(40), 0L, System.currentTimeMillis())
            )
            AiChatResult.Success(response.reply, response.remainingMessagesToday)
        } catch (e: HttpException) {
            if (e.code() == 429) {
                AiChatResult.RateLimited("You've reached today's AI message limit. Upgrade to Premium for a higher limit.")
            } else {
                markErrorMessage(conversationId)
                AiChatResult.ServerError("Livo AI couldn't process that message. Please try again.")
            }
        } catch (e: IOException) {
            markErrorMessage(conversationId)
            AiChatResult.NetworkError("You appear to be offline. Your message is saved — try again once you're back online.")
        }
    }

    /** Re-asks the AI using the existing last user turn, without re-inserting it into history. */
    suspend fun regenerateLast(conversationId: String, userId: String): AiChatResult {
        val messages = dao.observeMessages(conversationId).first()
        val lastUser = messages.lastOrNull { it.role == ChatRole.USER } ?: return AiChatResult.ServerError("Nothing to regenerate.")
        val lastAssistant = messages.lastOrNull { it.role == ChatRole.ASSISTANT }
        if (lastAssistant != null) dao.deleteMessage(lastAssistant.id)

        val history = messages.filter { it.id != lastAssistant?.id }.takeLast(20).map {
            ChatTurnDto(role = if (it.role == ChatRole.USER) "user" else "assistant", content = it.content)
        }
        return try {
            val response = api.sendChatMessage(ChatRequestDto(conversationId, lastUser.content, history))
            dao.insertMessage(
                ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = conversationId,
                    role = ChatRole.ASSISTANT,
                    content = response.reply,
                    createdAtEpochMillis = System.currentTimeMillis()
                )
            )
            AiChatResult.Success(response.reply, response.remainingMessagesToday)
        } catch (e: HttpException) {
            if (e.code() == 429) AiChatResult.RateLimited("You've reached today's AI message limit. Upgrade to Premium for a higher limit.")
            else { markErrorMessage(conversationId); AiChatResult.ServerError("Livo AI couldn't process that message. Please try again.") }
        } catch (e: IOException) {
            markErrorMessage(conversationId)
            AiChatResult.NetworkError("You appear to be offline. Try again once you're back online.")
        }
    }

    private suspend fun markErrorMessage(conversationId: String) {
        dao.insertMessage(
            ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                conversationId = conversationId,
                role = ChatRole.ASSISTANT,
                content = "Something went wrong reaching Livo AI. Please check your connection and try again.",
                isError = true,
                createdAtEpochMillis = System.currentTimeMillis()
            )
        )
    }
}
