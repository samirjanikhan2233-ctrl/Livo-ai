package com.muhammadsamirkhankabir.livoai.data.repository

import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.data.local.dao.TaskDao
import com.muhammadsamirkhankabir.livoai.data.remote.LivoBackendApi
import com.muhammadsamirkhankabir.livoai.data.remote.SyncPushDto
import com.muhammadsamirkhankabir.livoai.util.NetworkMonitor
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implements the offline-mode requirement: local writes always happen (see the
 * *Repository classes), and this manager pushes anything flagged isSynced=false
 * to the backend once connectivity returns. Nothing here ever reports a fake
 * "synced" success — a failed push simply leaves isSynced=false for the next attempt.
 */
@Singleton
class SyncManager @Inject constructor(
    private val networkMonitor: NetworkMonitor,
    private val sessionManager: SessionManager,
    private val taskDao: TaskDao,
    private val api: LivoBackendApi
) {
    /** Call once when connectivity is confirmed online (e.g. from a NetworkMonitor collector in the app). */
    suspend fun syncPendingChanges() {
        val userId = sessionManager.currentUserId ?: return
        val isOnline = networkMonitor.isOnline.first()
        if (!isOnline) return

        val unsyncedTasks = taskDao.getUnsyncedTasks(userId)
        if (unsyncedTasks.isEmpty()) return

        try {
            val payload = SyncPushDto(
                tasks = unsyncedTasks.map { task ->
                    mapOf(
                        "id" to task.id, "title" to task.title, "isCompleted" to task.isCompleted,
                        "priority" to task.priority.name, "dueDateEpochDay" to task.dueDateEpochDay,
                        "isDeleted" to task.isDeleted, "updatedAtEpochMillis" to task.updatedAtEpochMillis
                    )
                }
            )
            val ack = api.pushChanges(payload)
            if (ack.success) {
                unsyncedTasks.filter { it.id in ack.syncedIds }.forEach { taskDao.update(it.copy(isSynced = true)) }
            }
        } catch (_: Exception) {
            // Leave isSynced=false; will retry on the next connectivity event.
        }
    }
}
