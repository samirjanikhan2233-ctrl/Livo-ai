package com.muhammadsamirkhankabir.livoai.ui.screens.planner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.data.local.entities.Priority
import com.muhammadsamirkhankabir.livoai.data.local.entities.TaskEntity
import kotlinx.coroutines.launch
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTaskScreen(
    taskId: String?,
    onDone: () -> Unit,
    onBack: () -> Unit,
    viewModel: TaskViewModel = hiltViewModel()
) {
    var title by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf(Priority.MEDIUM) }
    var isRecurring by remember { mutableStateOf(false) }
    var reminderEnabled by remember { mutableStateOf(false) }
    var dueDate by remember { mutableStateOf(LocalDate.now()) }
    val existingTasks by viewModel.filteredTasks.collectAsState()
    val existing = remember(taskId, existingTasks) { existingTasks.find { it.id == taskId } }
    val scope = rememberCoroutineScope()

    LaunchedEffect(existing) {
        existing?.let {
            title = it.title; notes = it.notes; priority = it.priority
            isRecurring = it.isRecurring; reminderEnabled = it.reminderEnabled
            dueDate = LocalDate.ofEpochDay(it.dueDateEpochDay)
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (taskId == null) "New task" else "Edit task") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
        )
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Spacer(Modifier.height(16.dp))

            Text("Priority", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Priority.entries.forEach { p ->
                    FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p.name.lowercase().replaceFirstChar { it.uppercase() }) })
                }
            }
            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Recurring task"); Switch(checked = isRecurring, onCheckedChange = { isRecurring = it })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Reminder"); Switch(checked = reminderEnabled, onCheckedChange = { reminderEnabled = it })
            }
            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    scope.launch {
                        viewModel.save(
                            existing, title, notes, priority, dueDate.toEpochDay(), null,
                            isRecurring, if (isRecurring) "DAILY" else null, reminderEnabled
                        )
                        onDone()
                    }
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(if (taskId == null) "Add task" else "Save changes") }
        }
    }
}
