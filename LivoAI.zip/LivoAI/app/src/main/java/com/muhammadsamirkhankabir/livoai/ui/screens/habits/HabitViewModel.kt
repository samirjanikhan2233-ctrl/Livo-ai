package com.muhammadsamirkhankabir.livoai.ui.screens.habits

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.HabitEntity
import com.muhammadsamirkhankabir.livoai.data.repository.HabitRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HabitViewModel @Inject constructor(
    private val repository: HabitRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val userId get() = sessionManager.currentUserId.orEmpty()

    val habits: StateFlow<List<HabitEntity>> =
        repository.observeHabits(userId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addHabit(name: String, icon: String = "star", targetDaysPerWeek: Int = 7) = viewModelScope.launch {
        repository.createHabit(
            HabitEntity(
                id = "", userId = userId, name = name, icon = icon,
                targetDaysPerWeek = targetDaysPerWeek, createdAtEpochMillis = System.currentTimeMillis()
            )
        )
    }

    fun toggleToday(habit: HabitEntity) = viewModelScope.launch { repository.toggleToday(habit, userId) }
    fun archive(id: String) = viewModelScope.launch { repository.archiveHabit(id) }
}
