package com.muhammadsamirkhankabir.livoai.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.AuthRepository
import com.muhammadsamirkhankabir.livoai.auth.AuthResult
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.billing.BillingManager
import com.muhammadsamirkhankabir.livoai.data.repository.GamificationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProfileUiState(
    val name: String = "",
    val email: String = "",
    val xp: Int = 0,
    val level: Int = 1,
    val isPremium: Boolean = false,
    val achievementsUnlocked: Int = 0,
    val achievementsTotal: Int = 0
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val sessionManager: SessionManager,
    private val authRepository: AuthRepository,
    private val gamificationRepository: GamificationRepository,
    private val billingManager: BillingManager
) : ViewModel() {

    private val userId get() = sessionManager.currentUserId.orEmpty()

    val deleteAccountResult = MutableStateFlow<String?>(null)

    val uiState: StateFlow<ProfileUiState> = combine(
        gamificationRepository.observeProgress(userId),
        gamificationRepository.observeAchievements(userId),
        billingManager.isPremiumVerified
    ) { progress, achievements, isPremium ->
        ProfileUiState(
            name = sessionManager.currentUserName ?: "Livo AI User",
            email = sessionManager.currentUserEmail ?: "",
            xp = progress?.xp ?: 0,
            level = progress?.level ?: 1,
            isPremium = isPremium,
            achievementsUnlocked = achievements.count { it.isUnlocked },
            achievementsTotal = achievements.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProfileUiState())

    fun logout() = authRepository.logout()

    fun deleteAccount() = viewModelScope.launch {
        when (val result = authRepository.deleteAccount()) {
            is AuthResult.Success -> deleteAccountResult.value = "success"
            is AuthResult.Error -> deleteAccountResult.value = result.message
        }
    }
}
