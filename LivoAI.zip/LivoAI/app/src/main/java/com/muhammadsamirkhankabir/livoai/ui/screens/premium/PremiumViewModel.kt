package com.muhammadsamirkhankabir.livoai.ui.screens.premium

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.billing.BillingManager
import com.muhammadsamirkhankabir.livoai.billing.PremiumOffer
import com.muhammadsamirkhankabir.livoai.billing.PurchaseUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PremiumViewModel @Inject constructor(
    val billingManager: BillingManager
) : ViewModel() {

    val offers = billingManager.availableOffers
    val purchaseState = billingManager.purchaseState
    val isPremium = billingManager.isPremiumVerified

    init {
        billingManager.startConnection()
    }

    fun restorePurchases() = billingManager.restorePurchases()

    fun refreshFromServer() = viewModelScope.launch { billingManager.refreshEntitlementFromServer() }
}
