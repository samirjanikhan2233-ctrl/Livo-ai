package com.muhammadsamirkhankabir.livoai.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class GoalCategory { STUDY, FITNESS, BUSINESS, SAVING, SKILL, PERSONAL }

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val description: String = "",
    val category: GoalCategory = GoalCategory.PERSONAL,
    val targetDateEpochDay: Long?,
    val progressPercent: Int = 0,
    val notes: String = "",
    val isCompleted: Boolean = false,
    val createdAtEpochMillis: Long,
    val isSynced: Boolean = false,
    val isDeleted: Boolean = false
)

@Entity(tableName = "milestones")
data class MilestoneEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val title: String,
    val isCompleted: Boolean = false,
    val orderIndex: Int = 0
)
