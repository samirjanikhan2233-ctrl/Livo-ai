package com.muhammadsamirkhankabir.livoai.data.local.dao

import androidx.room.*
import com.muhammadsamirkhankabir.livoai.data.local.entities.TaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE userId = :userId AND isDeleted = 0 ORDER BY dueDateEpochDay ASC, dueTimeMinutes ASC")
    fun observeTasks(userId: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE userId = :userId AND isCompleted = 0 AND isDeleted = 0 AND dueDateEpochDay = :epochDay")
    fun observeTasksForDay(userId: String, epochDay: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: String): TaskEntity?

    @Query("SELECT COUNT(*) FROM tasks WHERE userId = :userId AND isCompleted = 1 AND isDeleted = 0")
    fun observeCompletedCount(userId: String): Flow<Int>

    @Query("SELECT * FROM tasks WHERE userId = :userId AND isSynced = 0")
    suspend fun getUnsyncedTasks(userId: String): List<TaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    @Update
    suspend fun update(task: TaskEntity)

    @Query("UPDATE tasks SET isDeleted = 1, isSynced = 0, updatedAtEpochMillis = :now WHERE id = :id")
    suspend fun softDelete(id: String, now: Long)
}
