package com.muhammadsamirkhankabir.livoai.data.local.dao

import androidx.room.*
import com.muhammadsamirkhankabir.livoai.data.local.entities.HabitCompletionEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.HabitEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits WHERE userId = :userId AND isArchived = 0 AND isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun observeHabits(userId: String): Flow<List<HabitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(habit: HabitEntity)

    @Query("UPDATE habits SET isDeleted = 1, isSynced = 0 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT * FROM habits WHERE id = :id")
    suspend fun getById(id: String): HabitEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markCompletion(completion: HabitCompletionEntity)

    @Query("DELETE FROM habit_completions WHERE habitId = :habitId AND epochDay = :epochDay")
    suspend fun unmarkCompletion(habitId: String, epochDay: Long)

    @Query("SELECT * FROM habit_completions WHERE habitId = :habitId AND epochDay BETWEEN :start AND :end")
    fun observeCompletionsInRange(habitId: String, start: Long, end: Long): Flow<List<HabitCompletionEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM habit_completions WHERE habitId = :habitId AND epochDay = :epochDay)")
    suspend fun isCompletedOn(habitId: String, epochDay: Long): Boolean
}
