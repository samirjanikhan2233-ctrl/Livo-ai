package com.muhammadsamirkhankabir.livoai.navigation

object Destinations {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"

    const val HOME = "home"
    const val PLANNER = "planner"
    const val HABITS = "habits"
    const val FINANCE = "finance"
    const val AI_CHAT = "ai_chat"

    const val ADD_EDIT_TASK = "add_edit_task"
    const val ADD_TRANSACTION = "add_transaction"
    const val BUDGET = "budget"
    const val NOTES = "notes"
    const val ADD_EDIT_NOTE = "add_edit_note"
    const val GOALS = "goals"
    const val GOAL_DETAIL = "goal_detail"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val PREMIUM = "premium"
    const val ABOUT = "about"
    const val PRIVACY_POLICY = "privacy_policy"
    const val TERMS = "terms"
    const val SUPPORT = "support"

    val BOTTOM_NAV_ROUTES = listOf(HOME, PLANNER, HABITS, FINANCE, AI_CHAT)
}
