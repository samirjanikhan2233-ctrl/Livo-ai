package com.muhammadsamirkhankabir.livoai.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.billing.BillingManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.GoalEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.TaskEntity
import com.muhammadsamirkhankabir.livoai.data.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class HomeUiState(
    val userName: String = "",
    val todayTasks: List<TaskEntity> = emptyList(),
    val completedToday: Int = 0,
    val totalToday: Int = 0,
    val habitStreak: Int = 0,
    val currentGoal: GoalEntity? = null,
    val todaySpending: Double = 0.0,
    val xp: Int = 0,
    val level: Int = 1,
    val isPremium: Boolean = false
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    sessionManager: SessionManager,
    taskRepository: TaskRepository,
    habitRepository: HabitRepository,
    goalRepository: GoalRepository,
    financeRepository: FinanceRepository,
    gamificationRepository: GamificationRepository,
    billingManager: BillingManager
) : ViewModel() {

    private val userId = sessionManager.currentUserId.orEmpty()
    private val today = LocalDate.now().toEpochDay()

    init {
        viewModelScope.launch { gamificationRepository.ensureInitialized(userId) }
    }

    val uiState: StateFlow<HomeUiState> = combine(
        taskRepository.observeTasksForDay(userId, today),
        habitRepository.observeHabits(userId),
        goalRepository.observeActiveGoal(userId),
        financeRepository.observeTransactions(userId),
        gamificationRepository.observeProgress(userId),
        billingManager.isPremiumVerified
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val tasks = values[0] as List<TaskEntity>
        @Suppress("UNCHECKED_CAST")
        val habits = values[1] as List<com.muhammadsamirkhankabir.livoai.data.local.entities.HabitEntity>
        val goal = values[2] as GoalEntity?
        @Suppress("UNCHECKED_CAST")
        val transactions = values[3] as List<com.muhammadsamirkhankabir.livoai.data.local.entities.TransactionEntity>
        val progress = values[4] as com.muhammadsamirkhankabir.livoai.data.local.entities.UserProgressEntity?
        val isPremium = values[5] as Boolean

        val todaySpent = transactions.filter {
            it.dateEpochDay == today && it.type == com.muhammadsamirkhankabir.livoai.data.local.entities.TransactionType.EXPENSE
        }.sumOf { it.amount }

        HomeUiState(
            userName = sessionManager.currentUserName ?: sessionManager.currentUserEmail?.substringBefore("@") ?: "there",
            todayTasks = tasks,
            completedToday = tasks.count { it.isCompleted },
            totalToday = tasks.size,
            habitStreak = habits.maxOfOrNull { it.currentStreak } ?: 0,
            currentGoal = goal,
            todaySpending = todaySpent,
            xp = progress?.xp ?: 0,
            level = progress?.level ?: 1,
            isPremium = isPremium
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())
}
