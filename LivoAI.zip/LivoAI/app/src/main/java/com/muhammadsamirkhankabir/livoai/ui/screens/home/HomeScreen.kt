package com.muhammadsamirkhankabir.livoai.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.ads.AdManager
import com.muhammadsamirkhankabir.livoai.ui.components.BannerAdSlot
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(
    onAddTask: () -> Unit,
    onAddHabit: () -> Unit,
    onAddExpense: () -> Unit,
    onAddNote: () -> Unit,
    onAddGoal: () -> Unit,
    onAskAi: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenPremium: () -> Unit,
    adManager: AdManager,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val today = remember { LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d", Locale.getDefault())) }
    val greeting = remember {
        when (java.time.LocalTime.now().hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Livo AI") },
                actions = {
                    IconButton(onClick = onOpenProfile) { Icon(Icons.Filled.Person, contentDescription = "Profile") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {

                Text("$greeting, ${state.userName}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(today, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(16.dp))

                // Daily progress
                val progress = if (state.totalToday == 0) 0f else state.completedToday.toFloat() / state.totalToday
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Today's progress", style = MaterialTheme.typography.titleMedium)
                            Text("${state.completedToday}/${state.totalToday} tasks")
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))

                // Stat row: streak, XP/level, spending
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(Modifier.weight(1f), "🔥 ${state.habitStreak}d", "Habit streak")
                    StatCard(Modifier.weight(1f), "Lv.${state.level}", "${state.xp} XP")
                    StatCard(Modifier.weight(1f), "$${"%.0f".format(state.todaySpending)}", "Spent today")
                }
                Spacer(Modifier.height(12.dp))

                state.currentGoal?.let { goal ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Current goal", style = MaterialTheme.typography.titleMedium)
                            Text(goal.title, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(progress = { goal.progressPercent / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp))
                            Text("${goal.progressPercent}% complete", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                // AI suggestion card
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("AI Suggestion", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (state.totalToday == 0) "Ask Livo AI to plan your day."
                                else "You've completed ${state.completedToday} of ${state.totalToday} tasks — keep going!",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        TextButton(onClick = onAskAi) { Text("Ask AI") }
                    }
                }
                Spacer(Modifier.height(16.dp))

                Text("Quick actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                QuickActionsGrid(onAddTask, onAddHabit, onAddExpense, onAddNote, onAddGoal, onAskAi)

                if (!state.isPremium) {
                    Spacer(Modifier.height(16.dp))
                    OutlinedCard(Modifier.fillMaxWidth(), onClick = onOpenPremium) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.WorkspacePremium, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Go Premium", fontWeight = FontWeight.SemiBold)
                                Text("Remove ads, unlock advanced AI & analytics", style = MaterialTheme.typography.bodySmall)
                            }
                            Icon(Icons.Filled.ChevronRight, contentDescription = null)
                        }
                    }
                }
                Spacer(Modifier.height(80.dp))
            }
            BannerAdSlot(adManager)
        }
    }
}

@Composable
private fun StatCard(modifier: Modifier, value: String, label: String) {
    ElevatedCard(modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun QuickActionsGrid(
    onAddTask: () -> Unit, onAddHabit: () -> Unit, onAddExpense: () -> Unit,
    onAddNote: () -> Unit, onAddGoal: () -> Unit, onAskAi: () -> Unit
) {
    val actions: List<Triple<String, ImageVector, () -> Unit>> = listOf(
        Triple("+ Task", Icons.Filled.AddTask, onAddTask),
        Triple("+ Habit", Icons.Filled.Loop, onAddHabit),
        Triple("+ Expense", Icons.Filled.Payments, onAddExpense),
        Triple("+ Note", Icons.Filled.NoteAdd, onAddNote),
        Triple("+ Goal", Icons.Filled.Flag, onAddGoal),
        Triple("Ask AI", Icons.Filled.AutoAwesome, onAskAi),
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        actions.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, icon, onClick) ->
                    OutlinedCard(onClick = onClick, modifier = Modifier.weight(1f)) {
                        Column(
                            Modifier.padding(vertical = 12.dp).fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(icon, contentDescription = label)
                            Spacer(Modifier.height(4.dp))
                            Text(label, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
