package com.muhammadsamirkhankabir.livoai.data.local.dao

import androidx.room.*
import com.muhammadsamirkhankabir.livoai.data.local.entities.AchievementEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.UserProgressEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GamificationDao {
    @Query("SELECT * FROM user_progress WHERE userId = :userId LIMIT 1")
    fun observeProgress(userId: String): Flow<UserProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(progress: UserProgressEntity)

    @Query("SELECT * FROM achievements WHERE userId = :userId ORDER BY isUnlocked DESC")
    fun observeAchievements(userId: String): Flow<List<AchievementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAchievement(achievement: AchievementEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllAchievements(achievements: List<AchievementEntity>)
}
