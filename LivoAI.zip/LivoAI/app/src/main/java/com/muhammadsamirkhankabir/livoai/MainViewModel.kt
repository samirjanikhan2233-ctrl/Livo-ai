package com.muhammadsamirkhankabir.livoai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.navigation.Destinations
import com.muhammadsamirkhankabir.livoai.util.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val sessionManager: SessionManager,
    private val settingsStore: SettingsStore
) : ViewModel() {

    val isLoading = MutableStateFlow(true)
    val startDestination = MutableStateFlow<String?>(null)
    val themeMode = settingsStore.themeMode

    init {
        viewModelScope.launch {
            settingsStore.loadThemeMode()
            val onboardingDone = settingsStore.isOnboardingComplete()
            val loggedIn = sessionManager.isLoggedIn()

            startDestination.value = when {
                !onboardingDone -> Destinations.ONBOARDING
                !loggedIn -> Destinations.LOGIN
                else -> Destinations.HOME
            }
            isLoading.value = false
        }
    }
}
