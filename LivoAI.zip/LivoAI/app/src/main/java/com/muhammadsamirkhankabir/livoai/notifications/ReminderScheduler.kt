package com.muhammadsamirkhankabir.livoai.notifications

import android.content.Context
import androidx.work.*
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReminderScheduler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val workManager = WorkManager.getInstance(context)

    fun scheduleTaskReminder(taskId: String, title: String, delayMillis: Long) =
        schedule("task_$taskId", ReminderWorker.TYPE_TASK, taskId, title, delayMillis)

    fun scheduleHabitReminder(habitId: String, name: String, delayMillis: Long) =
        schedule("habit_$habitId", ReminderWorker.TYPE_HABIT, habitId, name, delayMillis)

    fun scheduleGoalReminder(goalId: String, title: String, delayMillis: Long) =
        schedule("goal_$goalId", ReminderWorker.TYPE_GOAL, goalId, title, delayMillis)

    fun scheduleBudgetAlert(message: String, delayMillis: Long = 0) =
        schedule("budget_${System.currentTimeMillis()}", ReminderWorker.TYPE_BUDGET, "budget", message, delayMillis)

    fun cancel(uniqueWorkName: String) = workManager.cancelUniqueWork(uniqueWorkName)

    private fun schedule(uniqueName: String, type: String, id: String, title: String, delayMillis: Long) {
        val data = workDataOf(
            ReminderWorker.KEY_TYPE to type,
            ReminderWorker.KEY_ID to id,
            ReminderWorker.KEY_TITLE to title
        )
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delayMillis.coerceAtLeast(0), TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()
        workManager.enqueueUniqueWork(uniqueName, ExistingWorkPolicy.REPLACE, request)
    }
}
