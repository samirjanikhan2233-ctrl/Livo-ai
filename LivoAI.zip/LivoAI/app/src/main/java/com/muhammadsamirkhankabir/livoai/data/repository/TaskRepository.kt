package com.muhammadsamirkhankabir.livoai.data.repository

import com.muhammadsamirkhankabir.livoai.data.local.dao.GamificationDao
import com.muhammadsamirkhankabir.livoai.data.local.dao.TaskDao
import com.muhammadsamirkhankabir.livoai.data.local.entities.TaskEntity
import com.muhammadsamirkhankabir.livoai.gamification.XpManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Source of truth is always the local Room database (offline-first). Writes succeed
 * instantly offline and are flagged isSynced=false for [SyncManager] to push later —
 * so the app never lies to the user about an operation "succeeding" online when it
 * only happened locally; the UI shows a small "pending sync" indicator instead.
 */
@Singleton
class TaskRepository @Inject constructor(
    private val dao: TaskDao,
    private val gamificationDao: GamificationDao,
    private val xpManager: XpManager
) {
    fun observeTasks(userId: String): Flow<List<TaskEntity>> = dao.observeTasks(userId)
    fun observeTasksForDay(userId: String, epochDay: Long) = dao.observeTasksForDay(userId, epochDay)
    fun observeCompletedCount(userId: String) = dao.observeCompletedCount(userId)

    suspend fun createTask(task: TaskEntity) = dao.upsert(task.copy(id = task.id.ifBlank { UUID.randomUUID().toString() }))

    suspend fun updateTask(task: TaskEntity) =
        dao.update(task.copy(updatedAtEpochMillis = System.currentTimeMillis(), isSynced = false))

    suspend fun deleteTask(id: String) = dao.softDelete(id, System.currentTimeMillis())

    suspend fun toggleComplete(task: TaskEntity, userId: String) {
        val nowCompleted = !task.isCompleted
        dao.update(
            task.copy(
                isCompleted = nowCompleted,
                completedAtEpochMillis = if (nowCompleted) System.currentTimeMillis() else null,
                updatedAtEpochMillis = System.currentTimeMillis(),
                isSynced = false
            )
        )
        if (nowCompleted) {
            val progress = gamificationDao.observeProgress(userId).first()
            xpManager.awardXp(userId, com.muhammadsamirkhankabir.livoai.util.Constants.XP_TASK_COMPLETE, progress)
            val completedCount = dao.observeCompletedCount(userId).first()
            if (completedCount == 1) xpManager.unlock(userId, "FIRST_TASK")
            if (completedCount == 10) xpManager.unlock(userId, "TEN_TASKS")
        }
    }
}
