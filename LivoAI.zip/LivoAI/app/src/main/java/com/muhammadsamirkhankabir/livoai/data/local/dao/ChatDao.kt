package com.muhammadsamirkhankabir.livoai.data.local.dao

import androidx.room.*
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatConversationEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.ChatMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_conversations WHERE userId = :userId ORDER BY updatedAtEpochMillis DESC")
    fun observeConversations(userId: String): Flow<List<ChatConversationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConversation(conversation: ChatConversationEntity)

    @Query("DELETE FROM chat_conversations WHERE id = :id")
    suspend fun deleteConversation(id: String)

    @Query("DELETE FROM chat_messages WHERE conversationId = :id")
    suspend fun deleteMessagesFor(id: String)

    @Query("SELECT * FROM chat_messages WHERE conversationId = :conversationId ORDER BY createdAtEpochMillis ASC")
    fun observeMessages(conversationId: String): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteMessage(id: String)
}
