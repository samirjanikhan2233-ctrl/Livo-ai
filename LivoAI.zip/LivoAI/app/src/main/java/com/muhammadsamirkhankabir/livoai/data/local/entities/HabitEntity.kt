package com.muhammadsamirkhankabir.livoai.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val name: String,
    val icon: String = "star",
    val targetDaysPerWeek: Int = 7,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val createdAtEpochMillis: Long,
    val isArchived: Boolean = false,
    val isSynced: Boolean = false,
    val isDeleted: Boolean = false
)

@Entity(tableName = "habit_completions", primaryKeys = ["habitId", "epochDay"])
data class HabitCompletionEntity(
    val habitId: String,
    val epochDay: Long,
    val completedAtEpochMillis: Long
)
