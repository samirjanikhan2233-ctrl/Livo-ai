package com.muhammadsamirkhankabir.livoai.data.repository

import com.muhammadsamirkhankabir.livoai.data.local.dao.GamificationDao
import com.muhammadsamirkhankabir.livoai.data.local.dao.HabitDao
import com.muhammadsamirkhankabir.livoai.data.local.entities.HabitCompletionEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.HabitEntity
import com.muhammadsamirkhankabir.livoai.gamification.XpManager
import com.muhammadsamirkhankabir.livoai.util.Constants
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HabitRepository @Inject constructor(
    private val dao: HabitDao,
    private val gamificationDao: GamificationDao,
    private val xpManager: XpManager
) {
    fun observeHabits(userId: String) = dao.observeHabits(userId)
    fun observeCompletionsInRange(habitId: String, start: Long, end: Long) =
        dao.observeCompletionsInRange(habitId, start, end)

    suspend fun createHabit(habit: HabitEntity) =
        dao.upsert(habit.copy(id = habit.id.ifBlank { UUID.randomUUID().toString() }))

    suspend fun archiveHabit(id: String) = dao.softDelete(id)

    /** Toggling completion recalculates the streak from actual completion history (no manual fudging). */
    suspend fun toggleToday(habit: HabitEntity, userId: String) {
        val today = LocalDate.now().toEpochDay()
        val alreadyDone = dao.isCompletedOn(habit.id, today)

        if (alreadyDone) {
            dao.unmarkCompletion(habit.id, today)
        } else {
            dao.markCompletion(HabitCompletionEntity(habit.id, today, System.currentTimeMillis()))
            val progress = gamificationDao.observeProgress(userId).first()
            xpManager.awardXp(userId, Constants.XP_HABIT_COMPLETE, progress)
        }

        val newStreak = calculateStreak(habit.id, today)
        val best = maxOf(habit.bestStreak, newStreak)
        dao.upsert(habit.copy(currentStreak = newStreak, bestStreak = best))
        if (newStreak >= 7) xpManager.unlock(userId, "SEVEN_DAY_STREAK")
    }

    private suspend fun calculateStreak(habitId: String, fromEpochDay: Long): Int {
        var streak = 0
        var day = fromEpochDay
        while (dao.isCompletedOn(habitId, day)) {
            streak++
            day--
        }
        return streak
    }
}
