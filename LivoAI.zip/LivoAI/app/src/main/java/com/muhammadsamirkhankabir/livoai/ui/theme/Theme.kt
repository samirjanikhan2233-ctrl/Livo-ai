package com.muhammadsamirkhankabir.livoai.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.muhammadsamirkhankabir.livoai.util.ThemeMode

private val LightColors = lightColorScheme(
    primary = LivoPrimary, onPrimary = LivoOnPrimary, secondary = LivoSecondary,
    background = LivoBackgroundLight, surface = LivoSurfaceLight,
    onBackground = LivoTextLight, onSurface = LivoTextLight, error = LivoError
)

private val DarkColors = darkColorScheme(
    primary = LivoPrimary, onPrimary = LivoOnPrimary, secondary = LivoSecondary,
    background = LivoBackgroundDark, surface = LivoSurfaceDark,
    onBackground = LivoTextDark, onSurface = LivoTextDark, error = LivoError
)

@Composable
fun LivoAITheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = false, // Premium "extra customization" can toggle this on
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> systemDark
    }
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (useDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        useDark -> DarkColors
        else -> LightColors
    }

    MaterialTheme(colorScheme = colorScheme, typography = LivoTypography, content = content)
}
