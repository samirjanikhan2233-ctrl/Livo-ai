package com.muhammadsamirkhankabir.livoai.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.muhammadsamirkhankabir.livoai.BuildConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Centralized AdMob manager (per spec: "Create a centralized AdManager").
 *
 * Rules enforced here:
 *  - Ads only ever render for FREE users. Callers must check [shouldShowAds] first;
 *    Premium users (isPremiumVerified == true, from the server-verified BillingManager)
 *    never see a banner or rewarded prompt.
 *  - Ad unit IDs come from BuildConfig, which defaults to Google's official AdMob TEST
 *    ad unit IDs for debug builds. Real production IDs are injected at build time via
 *    local.properties / CI secrets (ADMOB_APP_ID, ADMOB_BANNER_ID, ADMOB_REWARDED_ID) —
 *    never hard-coded here.
 *  - No auto-click simulation, no ads layered over tappable UI (enforced in the
 *    composables that host BannerAdView).
 */
@Singleton
class AdManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    val isPremium = MutableStateFlow(false) // wired from BillingManager.isPremiumVerified in the DI graph

    fun shouldShowAds(): Boolean = !isPremium.value

    val bannerAdUnitId: String get() = BuildConfig.ADMOB_BANNER_ID

    private var rewardedAd: RewardedAd? = null

    fun preloadRewardedAd() {
        if (!shouldShowAds()) return
        RewardedAd.load(
            context,
            BuildConfig.ADMOB_REWARDED_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            }
        )
    }

    /** Shows an optional rewarded ad (e.g. "watch an ad to unlock 5 bonus AI messages today"). */
    fun showRewardedAd(activity: Activity, onRewardEarned: () -> Unit, onUnavailable: () -> Unit) {
        val ad = rewardedAd
        if (!shouldShowAds() || ad == null) {
            onUnavailable()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                preloadRewardedAd()
            }
        }
        ad.show(activity) { onRewardEarned() }
    }
}
