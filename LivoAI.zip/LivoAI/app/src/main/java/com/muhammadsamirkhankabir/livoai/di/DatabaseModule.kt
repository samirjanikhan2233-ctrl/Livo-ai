package com.muhammadsamirkhankabir.livoai.di

import android.content.Context
import androidx.room.Room
import com.muhammadsamirkhankabir.livoai.data.local.AppDatabase
import com.muhammadsamirkhankabir.livoai.util.Constants
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, Constants.DATABASE_NAME)
            // Local cache only — never store this file in cloud backup (see backup_rules.xml)
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideTaskDao(db: AppDatabase) = db.taskDao()
    @Provides fun provideHabitDao(db: AppDatabase) = db.habitDao()
    @Provides fun provideGoalDao(db: AppDatabase) = db.goalDao()
    @Provides fun provideNoteDao(db: AppDatabase) = db.noteDao()
    @Provides fun provideFinanceDao(db: AppDatabase) = db.financeDao()
    @Provides fun provideChatDao(db: AppDatabase) = db.chatDao()
    @Provides fun provideGamificationDao(db: AppDatabase) = db.gamificationDao()
}
