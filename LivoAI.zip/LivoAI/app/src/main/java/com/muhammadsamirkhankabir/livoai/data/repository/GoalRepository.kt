package com.muhammadsamirkhankabir.livoai.data.repository

import com.muhammadsamirkhankabir.livoai.data.local.dao.GamificationDao
import com.muhammadsamirkhankabir.livoai.data.local.dao.GoalDao
import com.muhammadsamirkhankabir.livoai.data.local.entities.GoalEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.MilestoneEntity
import com.muhammadsamirkhankabir.livoai.gamification.XpManager
import com.muhammadsamirkhankabir.livoai.util.Constants
import kotlinx.coroutines.flow.first
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalRepository @Inject constructor(
    private val dao: GoalDao,
    private val gamificationDao: GamificationDao,
    private val xpManager: XpManager
) {
    fun observeGoals(userId: String) = dao.observeGoals(userId)
    fun observeActiveGoal(userId: String) = dao.observeActiveGoal(userId)
    fun observeMilestones(goalId: String) = dao.observeMilestones(goalId)

    suspend fun createGoal(goal: GoalEntity, userId: String): String {
        val id = goal.id.ifBlank { UUID.randomUUID().toString() }
        dao.upsert(goal.copy(id = id))
        val existing = dao.observeGoals(userId).first()
        if (existing.size <= 1) xpManager.unlock(userId, "FIRST_GOAL")
        return id
    }

    suspend fun updateGoal(goal: GoalEntity) = dao.upsert(goal.copy(isSynced = false))

    suspend fun deleteGoal(id: String) = dao.softDelete(id)

    suspend fun setMilestones(goalId: String, titles: List<String>) {
        val milestones = titles.mapIndexed { index, title ->
            MilestoneEntity(id = UUID.randomUUID().toString(), goalId = goalId, title = title, orderIndex = index)
        }
        dao.upsertMilestones(milestones)
    }

    suspend fun toggleMilestone(milestone: MilestoneEntity, goal: GoalEntity, userId: String) {
        val nowCompleted = !milestone.isCompleted
        dao.upsertMilestone(milestone.copy(isCompleted = nowCompleted))

        val all = dao.observeMilestones(goal.id).first()
        val doneCount = all.count { it.isCompleted }
        val total = all.size.coerceAtLeast(1)
        val progress = ((doneCount.toFloat() / total) * 100).toInt().coerceIn(0, 100)
        val isNowComplete = progress >= 100
        dao.upsert(goal.copy(progressPercent = progress, isCompleted = isNowComplete, isSynced = false))

        val gProgress = gamificationDao.observeProgress(userId).first()
        if (nowCompleted) {
            xpManager.awardXp(userId, Constants.XP_GOAL_MILESTONE, gProgress)
        }
        if (isNowComplete && !goal.isCompleted) {
            xpManager.awardXp(userId, Constants.XP_GOAL_COMPLETE, gProgress)
        }
    }
}
