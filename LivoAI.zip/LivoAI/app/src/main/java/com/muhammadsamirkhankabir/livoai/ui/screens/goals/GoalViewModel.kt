package com.muhammadsamirkhankabir.livoai.ui.screens.goals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.GoalCategory
import com.muhammadsamirkhankabir.livoai.data.local.entities.GoalEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.MilestoneEntity
import com.muhammadsamirkhankabir.livoai.data.remote.GoalBreakdownRequestDto
import com.muhammadsamirkhankabir.livoai.data.remote.LivoBackendApi
import com.muhammadsamirkhankabir.livoai.data.repository.GoalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GoalViewModel @Inject constructor(
    private val repository: GoalRepository,
    private val sessionManager: SessionManager,
    private val api: LivoBackendApi
) : ViewModel() {

    private val userId get() = sessionManager.currentUserId.orEmpty()

    val goals: StateFlow<List<GoalEntity>> =
        repository.observeGoals(userId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val breakdownLoading = MutableStateFlow(false)
    val breakdownError = MutableStateFlow<String?>(null)

    fun milestonesFor(goalId: String) = repository.observeMilestones(goalId)

    fun createGoal(title: String, description: String, category: GoalCategory, targetDateEpochDay: Long?) = viewModelScope.launch {
        repository.createGoal(
            GoalEntity(
                id = "", userId = userId, title = title, description = description, category = category,
                targetDateEpochDay = targetDateEpochDay, createdAtEpochMillis = System.currentTimeMillis()
            ),
            userId
        )
    }

    fun deleteGoal(id: String) = viewModelScope.launch { repository.deleteGoal(id) }

    fun toggleMilestone(milestone: MilestoneEntity, goal: GoalEntity) = viewModelScope.launch {
        repository.toggleMilestone(milestone, goal, userId)
    }

    /** AI Goal Breakdown — user explicitly taps a button; suggestions are inserted only after this call returns. */
    fun requestAiBreakdown(goal: GoalEntity) = viewModelScope.launch {
        breakdownLoading.value = true
        breakdownError.value = null
        try {
            val response = api.breakDownGoal(
                GoalBreakdownRequestDto(goal.title, goal.description, goal.targetDateEpochDay?.toString())
            )
            repository.setMilestones(goal.id, response.milestones)
        } catch (e: Exception) {
            breakdownError.value = "Couldn't reach Livo AI to break down this goal. Please try again."
        } finally {
            breakdownLoading.value = false
        }
    }
}
