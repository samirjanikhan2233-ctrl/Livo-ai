package com.muhammadsamirkhankabir.livoai.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val content: String,
    val category: String = "General",
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val aiSummary: String? = null,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
    val isSynced: Boolean = false,
    val isDeleted: Boolean = false
)
