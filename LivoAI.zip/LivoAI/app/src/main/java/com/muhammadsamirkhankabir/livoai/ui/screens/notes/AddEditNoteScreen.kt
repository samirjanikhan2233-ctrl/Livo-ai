package com.muhammadsamirkhankabir.livoai.ui.screens.notes

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditNoteScreen(noteId: String?, onDone: () -> Unit, onBack: () -> Unit, viewModel: NoteViewModel = hiltViewModel()) {
    val notes by viewModel.notes.collectAsState()
    val existing = remember(noteId, notes) { notes.find { it.id == noteId } }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }

    LaunchedEffect(existing) { existing?.let { title = it.title; content = it.content; category = it.category } }

    Scaffold(topBar = {
        TopAppBar(title = { Text(if (noteId == null) "New note" else "Edit note") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth().weight(1f), minLines = 8)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { viewModel.save(existing, title, content, category); onDone() },
                enabled = title.isNotBlank() || content.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Save note") }
        }
    }
}
