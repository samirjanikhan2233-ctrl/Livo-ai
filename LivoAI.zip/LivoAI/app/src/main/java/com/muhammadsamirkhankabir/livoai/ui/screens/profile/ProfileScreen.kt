package com.muhammadsamirkhankabir.livoai.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onOpenSettings: () -> Unit,
    onOpenPremium: () -> Unit,
    onLoggedOut: () -> Unit,
    onBack: () -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val deleteResult by viewModel.deleteAccountResult.collectAsState()
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(deleteResult) { if (deleteResult == "success") onLoggedOut() }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Profile") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
            actions = { IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, contentDescription = "Settings") } }
        )
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Box(
                Modifier.size(88.dp).align(Alignment.CenterHorizontally)
                    .background(MaterialTheme.colorScheme.primaryContainer, androidx.compose.foundation.shape.CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Person, contentDescription = null, modifier = Modifier.size(48.dp)) }
            Spacer(Modifier.height(12.dp))
            Text(state.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            Text(state.email, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.align(Alignment.CenterHorizontally))
            if (state.isPremium) {
                Spacer(Modifier.height(4.dp))
                AssistChip(onClick = {}, label = { Text("Premium member") }, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
            Spacer(Modifier.height(20.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatBox(Modifier.weight(1f), "Lv.${state.level}", "Level")
                StatBox(Modifier.weight(1f), "${state.xp}", "XP")
                StatBox(Modifier.weight(1f), "${state.achievementsUnlocked}/${state.achievementsTotal}", "Achievements")
            }
            Spacer(Modifier.height(20.dp))

            if (!state.isPremium) {
                Button(onClick = onOpenPremium, modifier = Modifier.fillMaxWidth()) { Text("Upgrade to Premium") }
                Spacer(Modifier.height(12.dp))
            }

            OutlinedButton(onClick = { viewModel.logout(); onLoggedOut() }, modifier = Modifier.fillMaxWidth()) { Text("Log out") }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Delete account", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete your account?") },
            text = { Text("This permanently deletes your Livo AI account and all associated data. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { viewModel.deleteAccount(); confirmDelete = false }) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }

    if (deleteResult != null && deleteResult != "success") {
        Text(deleteResult ?: "", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
    }
}

@Composable
private fun StatBox(modifier: Modifier, value: String, label: String) {
    ElevatedCard(modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun Modifier.background(color: androidx.compose.ui.graphics.Color, shape: androidx.compose.ui.graphics.Shape) =
    this.then(androidx.compose.foundation.background(color, shape))
