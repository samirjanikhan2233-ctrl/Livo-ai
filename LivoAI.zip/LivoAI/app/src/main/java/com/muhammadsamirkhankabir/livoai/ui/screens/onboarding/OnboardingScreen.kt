package com.muhammadsamirkhankabir.livoai.ui.screens.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.util.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

private data class OnboardingPage(val title: String, val subtitle: String, val icon: ImageVector)

private val pages = listOf(
    OnboardingPage("Meet Livo AI", "Your all-in-one AI personal assistant for a more productive life.", Icons.Filled.AutoAwesome),
    OnboardingPage("Plan Your Day", "Build a smart daily plan with tasks, priorities and reminders.", Icons.Filled.CalendarToday),
    OnboardingPage("Build Better Habits", "Track streaks and build habits that actually stick.", Icons.Filled.Loop),
    OnboardingPage("Track Your Money", "See income, expenses and budgets at a glance.", Icons.Filled.AccountBalanceWallet),
    OnboardingPage("Reach Your Goals", "Break big goals into small, achievable milestones.", Icons.Filled.EmojiEvents),
)

@HiltViewModel
class OnboardingViewModel @Inject constructor(private val settingsStore: SettingsStore) : ViewModel() {
    fun complete(onDone: () -> Unit) {
        viewModelScope.launch {
            settingsStore.setOnboardingComplete()
            onDone()
        }
    }
}

@Composable
fun OnboardingScreen(onFinished: () -> Unit, viewModel: OnboardingViewModel = hiltViewModel()) {
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { viewModel.complete(onFinished) }) { Text("Skip") }
        }

        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { index ->
            val page = pages[index]
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.size(120.dp).background(MaterialTheme.colorScheme.primaryContainer, shapes()),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(page.icon, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(32.dp))
                Text(page.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text(page.subtitle, style = MaterialTheme.typography.bodyLarge, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }

        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center) {
            repeat(pages.size) { i ->
                Box(
                    Modifier.padding(4.dp).size(if (i == pagerState.currentPage) 10.dp else 8.dp)
                        .background(
                            if (i == pagerState.currentPage) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            shapes()
                        )
                )
            }
        }

        Button(
            onClick = {
                if (pagerState.currentPage == pages.lastIndex) {
                    viewModel.complete(onFinished)
                } else {
                    scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(24.dp)
        ) {
            Text(if (pagerState.currentPage == pages.lastIndex) "Get Started" else "Next")
        }
    }
}

private fun shapes() = androidx.compose.foundation.shape.CircleShape
