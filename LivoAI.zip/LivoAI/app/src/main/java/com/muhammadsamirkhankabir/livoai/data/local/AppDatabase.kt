package com.muhammadsamirkhankabir.livoai.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.muhammadsamirkhankabir.livoai.data.local.dao.*
import com.muhammadsamirkhankabir.livoai.data.local.entities.*

/**
 * Single local Room database backing Livo AI's offline mode. Every write also
 * flips `isSynced = false` so [com.muhammadsamirkhankabir.livoai.data.repository.SyncManager]
 * knows what to push to the backend once connectivity returns.
 */
@Database(
    entities = [
        TaskEntity::class,
        HabitEntity::class, HabitCompletionEntity::class,
        GoalEntity::class, MilestoneEntity::class,
        NoteEntity::class,
        TransactionEntity::class, BudgetEntity::class,
        ChatConversationEntity::class, ChatMessageEntity::class,
        AchievementEntity::class, UserProgressEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun habitDao(): HabitDao
    abstract fun goalDao(): GoalDao
    abstract fun noteDao(): NoteDao
    abstract fun financeDao(): FinanceDao
    abstract fun chatDao(): ChatDao
    abstract fun gamificationDao(): GamificationDao
}
