package com.muhammadsamirkhankabir.livoai.data.remote

data class ChatRequestDto(
    val conversationId: String,
    val message: String,
    val history: List<ChatTurnDto> = emptyList()
)
data class ChatTurnDto(val role: String, val content: String)
data class ChatResponseDto(val reply: String, val remainingMessagesToday: Int? = null)

data class DailyPlanRequestDto(val scheduleDescription: String, val existingTasks: List<String> = emptyList())
data class DailyPlanResponseDto(val plan: List<PlannedItemDto>)
data class PlannedItemDto(val time: String, val title: String, val priority: String)

data class GoalBreakdownRequestDto(val goalTitle: String, val goalDescription: String, val targetDate: String?)
data class GoalBreakdownResponseDto(val milestones: List<String>)

data class SummarizeRequestDto(val noteContent: String)
data class SummarizeResponseDto(val summary: String)

data class FinanceInsightRequestDto(
    val question: String,
    val totalIncome: Double,
    val totalExpenses: Double,
    val categoryBreakdown: Map<String, Double>
)

data class SyncPushDto(
    val tasks: List<Map<String, Any?>> = emptyList(),
    val habits: List<Map<String, Any?>> = emptyList(),
    val goals: List<Map<String, Any?>> = emptyList(),
    val notes: List<Map<String, Any?>> = emptyList(),
    val transactions: List<Map<String, Any?>> = emptyList()
)
data class SyncAckDto(val success: Boolean, val syncedIds: List<String> = emptyList())
data class SyncPullDto(val serverTimestamp: Long, val changes: Map<String, Any?> = emptyMap())

data class VerifyPurchaseDto(val purchaseToken: String, val productId: String, val isSubscription: Boolean = true)
data class SubscriptionStatusDto(
    val isPremium: Boolean,
    val planId: String? = null,
    val expiryEpochMillis: Long? = null,
    val willRenew: Boolean = false
)

data class DeleteAccountAckDto(val success: Boolean)
