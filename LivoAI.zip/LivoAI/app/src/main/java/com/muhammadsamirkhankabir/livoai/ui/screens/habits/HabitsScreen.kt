package com.muhammadsamirkhankabir.livoai.ui.screens.habits

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.ads.AdManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.HabitEntity
import com.muhammadsamirkhankabir.livoai.ui.components.BannerAdSlot

@Composable
fun HabitsScreen(adManager: AdManager, viewModel: HabitViewModel = hiltViewModel()) {
    val habits by viewModel.habits.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Habits") }) },
        floatingActionButton = { FloatingActionButton(onClick = { showAddDialog = true }) { Icon(Icons.Filled.Add, contentDescription = "Add habit") } }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (habits.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No habits yet. Tap + to build your first one.")
                }
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp)) {
                    items(habits, key = { it.id }) { habit ->
                        HabitCard(habit, onToggle = { viewModel.toggleToday(habit) })
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
            BannerAdSlot(adManager)
        }
    }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("New habit") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Habit name, e.g. Drink water") }) },
            confirmButton = {
                TextButton(onClick = { if (name.isNotBlank()) { viewModel.addHabit(name); showAddDialog = false } }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun HabitCard(habit: HabitEntity, onToggle: () -> Unit) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(habit.name, style = MaterialTheme.typography.titleMedium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("${habit.currentStreak} day streak  •  best ${habit.bestStreak}", style = MaterialTheme.typography.bodySmall)
                }
            }
            FilledTonalButton(onClick = onToggle) { Text("Mark today") }
        }
    }
}
