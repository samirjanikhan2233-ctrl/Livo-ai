package com.muhammadsamirkhankabir.livoai.ui.screens.premium

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.billing.MONTHLY_SUB_ID
import com.muhammadsamirkhankabir.livoai.billing.PurchaseUiState
import com.muhammadsamirkhankabir.livoai.billing.YEARLY_SUB_ID
import com.muhammadsamirkhankabir.livoai.util.Constants

private val PREMIUM_FEATURES = listOf(
    "Higher AI message limits",
    "Advanced AI features (daily planning, deep goal insights)",
    "Advanced analytics & charts",
    "Premium themes & extra customization",
    "Completely ad-free experience"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumScreen(
    onBack: () -> Unit,
    onOpenTerms: () -> Unit,
    onOpenPrivacy: () -> Unit,
    viewModel: PremiumViewModel = hiltViewModel()
) {
    val offers by viewModel.offers.collectAsState()
    val purchaseState by viewModel.purchaseState.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    var selectedPlan by remember { mutableStateOf(YEARLY_SUB_ID) }
    val context = LocalContext.current

    Scaffold(topBar = {
        TopAppBar(title = { Text("Livo AI Premium") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            if (isPremium) {
                Text("You're a Premium member 🎉", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Thanks for supporting Livo AI. Ads are off and your limits are unlocked.")
            } else {
                Text("Unlock Livo AI Premium", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                PREMIUM_FEATURES.forEach { feature ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                        Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(feature)
                    }
                }
                Spacer(Modifier.height(20.dp))

                val monthly = offers.find { it.productId == MONTHLY_SUB_ID }
                val yearly = offers.find { it.productId == YEARLY_SUB_ID }

                PlanCard("Monthly", monthly?.formattedPrice ?: "—", selected = selectedPlan == MONTHLY_SUB_ID) { selectedPlan = MONTHLY_SUB_ID }
                Spacer(Modifier.height(8.dp))
                PlanCard("Yearly (best value)", yearly?.formattedPrice ?: "—", selected = selectedPlan == YEARLY_SUB_ID) { selectedPlan = YEARLY_SUB_ID }

                if (purchaseState is PurchaseUiState.Error) {
                    Spacer(Modifier.height(8.dp))
                    Text((purchaseState as PurchaseUiState.Error).message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        (context as? android.app.Activity)?.let { activity ->
                            viewModel.billingManager.launchPurchaseFlow(activity, selectedPlan)
                        }
                    },
                    enabled = purchaseState !is PurchaseUiState.Loading,
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    if (purchaseState is PurchaseUiState.Loading) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    else Text("Subscribe")
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { viewModel.restorePurchases() }, modifier = Modifier.fillMaxWidth()) { Text("Restore purchases") }
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                TextButton(onClick = onOpenTerms) { Text("Terms") }
                TextButton(onClick = onOpenPrivacy) { Text("Privacy Policy") }
            }
        }
    }
}

@Composable
private fun PlanCard(label: String, price: String, selected: Boolean, onClick: () -> Unit) {
    OutlinedCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.outlinedCardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontWeight = FontWeight.SemiBold)
            Text(price, fontWeight = FontWeight.Bold)
        }
    }
}
