package com.muhammadsamirkhankabir.livoai.data.remote

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Contract for Livo AI's own backend (see /backend for a reference Node/Express
 * implementation). The Android app NEVER talks to an AI vendor or Google Play
 * verification API directly — it only ever calls these endpoints, all of which
 * require a Firebase ID token (attached by NetworkModule's auth interceptor).
 */
interface LivoBackendApi {

    // --- AI chat (server holds the real AI_API_KEY) ---
    @POST("v1/ai/chat")
    suspend fun sendChatMessage(@Body request: ChatRequestDto): ChatResponseDto

    @POST("v1/ai/daily-plan")
    suspend fun generateDailyPlan(@Body request: DailyPlanRequestDto): DailyPlanResponseDto

    @POST("v1/ai/goal-breakdown")
    suspend fun breakDownGoal(@Body request: GoalBreakdownRequestDto): GoalBreakdownResponseDto

    @POST("v1/ai/summarize-note")
    suspend fun summarizeNote(@Body request: SummarizeRequestDto): SummarizeResponseDto

    @POST("v1/ai/finance-insight")
    suspend fun getFinanceInsight(@Body request: FinanceInsightRequestDto): ChatResponseDto

    // --- Sync (offline-first: push local changes, pull server changes) ---
    @POST("v1/sync/push")
    suspend fun pushChanges(@Body request: SyncPushDto): SyncAckDto

    @GET("v1/sync/pull")
    suspend fun pullChanges(@Query("since") sinceEpochMillis: Long): SyncPullDto

    // --- Billing (server verifies Play purchase tokens with Google, never the client) ---
    @POST("v1/billing/verify-purchase")
    suspend fun verifyPurchase(@Body request: VerifyPurchaseDto): SubscriptionStatusDto

    @GET("v1/billing/subscription-status")
    suspend fun getSubscriptionStatus(): SubscriptionStatusDto

    // --- Account ---
    @POST("v1/account/delete")
    suspend fun deleteAccount(): DeleteAccountAckDto
}
