package com.muhammadsamirkhankabir.livoai.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType { INCOME, EXPENSE }

enum class TransactionCategory {
    FOOD, TRANSPORT, SHOPPING, BILLS, EDUCATION, HEALTH, ENTERTAINMENT, BUSINESS, OTHER, INCOME
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val type: TransactionType,
    val category: TransactionCategory,
    val amount: Double,
    val note: String = "",
    val dateEpochDay: Long,
    val createdAtEpochMillis: Long,
    val isSynced: Boolean = false,
    val isDeleted: Boolean = false
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val id: String, // format: userId_yyyyMM
    val userId: String,
    val yearMonth: String, // "2026-09"
    val monthlyLimit: Double
)
