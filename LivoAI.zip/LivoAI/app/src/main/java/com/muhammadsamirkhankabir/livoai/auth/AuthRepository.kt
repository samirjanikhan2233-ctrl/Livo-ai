package com.muhammadsamirkhankabir.livoai.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

sealed class AuthResult {
    data object Success : AuthResult()
    data class Error(val message: String) : AuthResult()
}

/**
 * All authentication goes through Firebase Auth (industry-standard, salted/hashed
 * password storage, secure token issuance). Livo AI never stores or transmits raw
 * passwords itself.
 */
@Singleton
class AuthRepository @Inject constructor(
    private val firebaseAuth: FirebaseAuth
) {
    suspend fun register(name: String, email: String, password: String): AuthResult = try {
        val result = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
        result.user?.updateProfile(
            UserProfileChangeRequest.Builder().setDisplayName(name).build()
        )?.await()
        AuthResult.Success
    } catch (e: Exception) {
        AuthResult.Error(e.localizedMessage ?: "Registration failed. Please try again.")
    }

    suspend fun login(email: String, password: String): AuthResult = try {
        firebaseAuth.signInWithEmailAndPassword(email, password).await()
        AuthResult.Success
    } catch (e: Exception) {
        AuthResult.Error(e.localizedMessage ?: "Login failed. Check your email and password.")
    }

    suspend fun sendPasswordReset(email: String): AuthResult = try {
        firebaseAuth.sendPasswordResetEmail(email).await()
        AuthResult.Success
    } catch (e: Exception) {
        AuthResult.Error(e.localizedMessage ?: "Could not send reset email.")
    }

    suspend fun deleteAccount(): AuthResult = try {
        firebaseAuth.currentUser?.delete()?.await()
        AuthResult.Success
    } catch (e: Exception) {
        AuthResult.Error(e.localizedMessage ?: "Account deletion requires a recent login. Please log in again and retry.")
    }

    fun logout() = firebaseAuth.signOut()
}
