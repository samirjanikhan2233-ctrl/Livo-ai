package com.muhammadsamirkhankabir.livoai.notifications

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Optional server-pushed notifications (e.g. "you have a budget approaching its limit,
 * checked server-side"). Local reminders (tasks/habits/goals set on-device) use
 * [ReminderScheduler] + WorkManager instead and do not require this service.
 */
class ReminderFirebaseMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: return
        val body = message.notification?.body ?: return
        // Route into NotificationHelper via a lightweight EntryPoint if needed in production.
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // TODO: send token to backend so server-triggered alerts (budget, etc.) can reach this device.
    }
}
