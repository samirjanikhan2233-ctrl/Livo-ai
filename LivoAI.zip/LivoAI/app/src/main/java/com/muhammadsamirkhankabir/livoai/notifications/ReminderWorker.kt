package com.muhammadsamirkhankabir.livoai.notifications

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

/**
 * Fires a single local reminder notification. Scheduled per-item (task/habit/goal)
 * with WorkManager's unique work + exact delay, so reminders survive process death
 * and doze mode without needing a server push for purely local reminders.
 */
@HiltWorker
class ReminderWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val notificationHelper: NotificationHelper
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val type = inputData.getString(KEY_TYPE) ?: return Result.failure()
        val itemId = inputData.getString(KEY_ID) ?: return Result.failure()
        val title = inputData.getString(KEY_TITLE) ?: ""

        when (type) {
            TYPE_TASK -> notificationHelper.showTaskReminder(itemId, title)
            TYPE_HABIT -> notificationHelper.showHabitReminder(itemId, title)
            TYPE_GOAL -> notificationHelper.showGoalReminder(itemId, title)
            TYPE_BUDGET -> notificationHelper.showBudgetAlert(title)
        }
        return Result.success()
    }

    companion object {
        const val KEY_TYPE = "type"
        const val KEY_ID = "id"
        const val KEY_TITLE = "title"
        const val TYPE_TASK = "task"
        const val TYPE_HABIT = "habit"
        const val TYPE_GOAL = "goal"
        const val TYPE_BUDGET = "budget"
    }
}
