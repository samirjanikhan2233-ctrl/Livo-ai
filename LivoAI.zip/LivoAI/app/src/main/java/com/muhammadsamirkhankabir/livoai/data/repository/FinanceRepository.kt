package com.muhammadsamirkhankabir.livoai.data.repository

import com.muhammadsamirkhankabir.livoai.data.local.dao.FinanceDao
import com.muhammadsamirkhankabir.livoai.data.local.entities.BudgetEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.TransactionEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.TransactionType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class FinanceSummary(
    val totalIncome: Double,
    val totalExpenses: Double,
    val balance: Double,
    val categoryBreakdown: Map<String, Double>
)

@Singleton
class FinanceRepository @Inject constructor(
    private val dao: FinanceDao
) {
    fun observeTransactions(userId: String) = dao.observeTransactions(userId)

    fun observeSummary(userId: String): Flow<FinanceSummary> =
        dao.observeTransactions(userId).map { list ->
            val income = list.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
            val expenses = list.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
            val breakdown = list.filter { it.type == TransactionType.EXPENSE }
                .groupBy { it.category.name }
                .mapValues { (_, txs) -> txs.sumOf { it.amount } }
            FinanceSummary(income, expenses, income - expenses, breakdown)
        }

    suspend fun addTransaction(transaction: TransactionEntity) =
        dao.upsert(transaction.copy(id = transaction.id.ifBlank { UUID.randomUUID().toString() }))

    suspend fun deleteTransaction(id: String) = dao.softDelete(id)

    fun observeBudget(userId: String, yearMonth: String = currentYearMonth()) = dao.observeBudget(userId, yearMonth)

    suspend fun setBudget(userId: String, monthlyLimit: Double, yearMonth: String = currentYearMonth()) {
        dao.upsertBudget(BudgetEntity(id = "${userId}_$yearMonth", userId = userId, yearMonth = yearMonth, monthlyLimit = monthlyLimit))
    }

    companion object {
        fun currentYearMonth(): String = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"))
    }
}
