package com.muhammadsamirkhankabir.livoai.notifications

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.muhammadsamirkhankabir.livoai.LivoApplication
import com.muhammadsamirkhankabir.livoai.R
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun hasPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun showTaskReminder(taskId: String, title: String) =
        show(taskId.hashCode(), LivoApplication.CHANNEL_TASKS, "Task reminder", title)

    fun showHabitReminder(habitId: String, name: String) =
        show(habitId.hashCode(), LivoApplication.CHANNEL_HABITS, "Habit reminder", "Time for: $name")

    fun showGoalReminder(goalId: String, title: String) =
        show(goalId.hashCode(), LivoApplication.CHANNEL_GOALS, "Goal check-in", title)

    fun showBudgetAlert(message: String) =
        show(9001, LivoApplication.CHANNEL_BUDGET, "Budget alert", message)

    private fun show(id: Int, channel: String, title: String, body: String) {
        if (!hasPermission()) return
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(id, notification)
    }
}
