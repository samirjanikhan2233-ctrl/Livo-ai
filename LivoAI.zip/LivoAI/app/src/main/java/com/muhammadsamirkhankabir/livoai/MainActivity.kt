package com.muhammadsamirkhankabir.livoai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.muhammadsamirkhankabir.livoai.navigation.LivoNavGraph
import com.muhammadsamirkhankabir.livoai.ui.theme.LivoAITheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-activity host. All screens are Compose destinations inside [LivoNavGraph].
 * The native splash stays on screen only until [MainViewModel] finishes checking
 * whether a session exists and whether onboarding was completed.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)

        splash.setKeepOnScreenCondition { viewModel.isLoading.value }

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val startDestination by viewModel.startDestination.collectAsState()

            LivoAITheme(themeMode = themeMode) {
                startDestination?.let { destination ->
                    LivoNavGraph(startDestination = destination)
                }
            }
        }
    }
}
