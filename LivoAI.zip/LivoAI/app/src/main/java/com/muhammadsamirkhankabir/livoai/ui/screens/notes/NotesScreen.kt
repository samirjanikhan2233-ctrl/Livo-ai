package com.muhammadsamirkhankabir.livoai.ui.screens.notes

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.muhammadsamirkhankabir.livoai.data.local.entities.NoteEntity

@Composable
fun NotesScreen(onAddNote: () -> Unit, onEditNote: (String) -> Unit, viewModel: NoteViewModel = hiltViewModel()) {
    val notes by viewModel.notes.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val summarizing by viewModel.summarizing.collectAsState()
    var confirmSummarizeFor by remember { mutableStateOf<NoteEntity?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Notes") }) },
        floatingActionButton = { FloatingActionButton(onClick = onAddNote) { Icon(Icons.Filled.Add, contentDescription = "Add note") } }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            OutlinedTextField(
                value = query, onValueChange = { viewModel.searchQuery.value = it },
                label = { Text("Search notes") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            if (notes.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("No notes yet.") }
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(notes.filter { !it.isArchived }, key = { it.id }) { note ->
                        NoteCard(
                            note,
                            isSummarizing = summarizing == note.id,
                            onClick = { onEditNote(note.id) },
                            onPin = { viewModel.togglePin(note) },
                            onArchive = { viewModel.toggleArchive(note) },
                            onDelete = { viewModel.delete(note.id) },
                            onSummarize = { confirmSummarizeFor = note }
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }

    // Confirmation is required before any AI action runs, per spec.
    confirmSummarizeFor?.let { note ->
        AlertDialog(
            onDismissRequest = { confirmSummarizeFor = null },
            title = { Text("Summarize with AI?") },
            text = { Text("Livo AI will send this note's content to generate a short summary. Continue?") },
            confirmButton = {
                TextButton(onClick = { viewModel.summarizeConfirmed(note); confirmSummarizeFor = null }) { Text("Summarize") }
            },
            dismissButton = { TextButton(onClick = { confirmSummarizeFor = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun NoteCard(
    note: NoteEntity, isSummarizing: Boolean, onClick: () -> Unit, onPin: () -> Unit,
    onArchive: () -> Unit, onDelete: () -> Unit, onSummarize: () -> Unit
) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(note.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = onPin) {
                    Icon(if (note.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin, contentDescription = "Pin")
                }
            }
            Text(note.content, maxLines = 3, style = MaterialTheme.typography.bodyMedium)
            note.aiSummary?.let {
                Spacer(Modifier.height(6.dp))
                Text("AI summary: $it", style = MaterialTheme.typography.bodySmall)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (isSummarizing) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    TextButton(onClick = onSummarize) { Text("Summarize with AI") }
                }
                TextButton(onClick = onArchive) { Text(if (note.isArchived) "Unarchive" else "Archive") }
                TextButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}
