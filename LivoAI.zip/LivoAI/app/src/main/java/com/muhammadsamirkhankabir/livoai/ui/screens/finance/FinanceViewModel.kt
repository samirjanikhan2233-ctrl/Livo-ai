package com.muhammadsamirkhankabir.livoai.ui.screens.finance

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.SessionManager
import com.muhammadsamirkhankabir.livoai.data.local.entities.*
import com.muhammadsamirkhankabir.livoai.data.remote.FinanceInsightRequestDto
import com.muhammadsamirkhankabir.livoai.data.remote.LivoBackendApi
import com.muhammadsamirkhankabir.livoai.data.repository.FinanceRepository
import com.muhammadsamirkhankabir.livoai.data.repository.FinanceSummary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class FinanceViewModel @Inject constructor(
    private val repository: FinanceRepository,
    private val sessionManager: SessionManager,
    private val api: LivoBackendApi
) : ViewModel() {

    private val userId get() = sessionManager.currentUserId.orEmpty()

    val transactions: StateFlow<List<TransactionEntity>> =
        repository.observeTransactions(userId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val summary: StateFlow<FinanceSummary> = repository.observeSummary(userId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinanceSummary(0.0, 0.0, 0.0, emptyMap()))

    val budget: StateFlow<BudgetEntity?> =
        repository.observeBudget(userId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val aiInsight = MutableStateFlow<String?>(null)
    val aiInsightLoading = MutableStateFlow(false)
    val aiInsightError = MutableStateFlow<String?>(null)

    fun addTransaction(type: TransactionType, category: TransactionCategory, amount: Double, note: String, dateEpochDay: Long = LocalDate.now().toEpochDay()) =
        viewModelScope.launch {
            repository.addTransaction(
                TransactionEntity(
                    id = "", userId = userId, type = type, category = category, amount = amount,
                    note = note, dateEpochDay = dateEpochDay, createdAtEpochMillis = System.currentTimeMillis()
                )
            )
        }

    fun deleteTransaction(id: String) = viewModelScope.launch { repository.deleteTransaction(id) }

    fun setBudget(limit: Double) = viewModelScope.launch { repository.setBudget(userId, limit) }

    /** Real backend call. Clearly informational, never professional financial advice (shown in UI copy). */
    fun askAiAboutFinances(question: String) = viewModelScope.launch {
        aiInsightLoading.value = true
        aiInsightError.value = null
        try {
            val s = summary.value
            val response = api.getFinanceInsight(
                FinanceInsightRequestDto(question, s.totalIncome, s.totalExpenses, s.categoryBreakdown)
            )
            aiInsight.value = response.reply
        } catch (e: Exception) {
            aiInsightError.value = "Couldn't reach Livo AI for a finance insight right now. Please try again."
        } finally {
            aiInsightLoading.value = false
        }
    }
}
