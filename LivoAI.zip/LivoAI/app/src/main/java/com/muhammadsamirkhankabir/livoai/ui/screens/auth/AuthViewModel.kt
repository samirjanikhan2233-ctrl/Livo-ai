package com.muhammadsamirkhankabir.livoai.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.muhammadsamirkhankabir.livoai.auth.AuthRepository
import com.muhammadsamirkhankabir.livoai.auth.AuthResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuthUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successEvent: Boolean = false
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val repository: AuthRepository
) : ViewModel() {

    private val _state = MutableStateFlow(AuthUiState())
    val state: StateFlow<AuthUiState> = _state

    fun login(email: String, password: String) {
        if (!validate(email, password)) return
        _state.value = _state.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            when (val result = repository.login(email.trim(), password)) {
                is AuthResult.Success -> _state.value = AuthUiState(successEvent = true)
                is AuthResult.Error -> _state.value = AuthUiState(errorMessage = result.message)
            }
        }
    }

    fun register(name: String, email: String, password: String, confirmPassword: String) {
        if (name.isBlank()) { _state.value = _state.value.copy(errorMessage = "Please enter your name."); return }
        if (!validate(email, password)) return
        if (password != confirmPassword) {
            _state.value = _state.value.copy(errorMessage = "Passwords do not match."); return
        }
        _state.value = _state.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            when (val result = repository.register(name.trim(), email.trim(), password)) {
                is AuthResult.Success -> _state.value = AuthUiState(successEvent = true)
                is AuthResult.Error -> _state.value = AuthUiState(errorMessage = result.message)
            }
        }
    }

    fun sendPasswordReset(email: String) {
        if (email.isBlank()) { _state.value = _state.value.copy(errorMessage = "Please enter your email."); return }
        _state.value = _state.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            when (val result = repository.sendPasswordReset(email.trim())) {
                is AuthResult.Success -> _state.value = AuthUiState(successEvent = true)
                is AuthResult.Error -> _state.value = AuthUiState(errorMessage = result.message)
            }
        }
    }

    private fun validate(email: String, password: String): Boolean {
        if (email.isBlank() || !email.contains("@")) {
            _state.value = _state.value.copy(errorMessage = "Please enter a valid email."); return false
        }
        if (password.length < 6) {
            _state.value = _state.value.copy(errorMessage = "Password must be at least 6 characters."); return false
        }
        return true
    }

    fun consumeError() { _state.value = _state.value.copy(errorMessage = null) }
}
