package com.muhammadsamirkhankabir.livoai.util

enum class ThemeMode { LIGHT, DARK, SYSTEM }

object Constants {
    const val DATABASE_NAME = "livo_ai.db"
    const val PREFS_NAME = "livo_settings_prefs"
    const val SESSION_PREFS = "session_prefs"

    // Free-tier limits (server also enforces these — never trust client alone)
    const val FREE_AI_MESSAGES_PER_DAY = 15
    const val PREMIUM_AI_MESSAGES_PER_DAY = 500

    // XP rewards
    const val XP_TASK_COMPLETE = 10
    const val XP_HABIT_COMPLETE = 15
    const val XP_GOAL_MILESTONE = 25
    const val XP_GOAL_COMPLETE = 100
    const val XP_DAILY_PLAN_COMPLETE = 20

    const val PRIVACY_POLICY_URL = "https://example.com/livo-ai/privacy-policy" // TODO: replace with real URL
    const val TERMS_URL = "https://example.com/livo-ai/terms" // TODO: replace with real URL
    const val SUPPORT_EMAIL = "support@example.com" // TODO: replace with real support email
}
