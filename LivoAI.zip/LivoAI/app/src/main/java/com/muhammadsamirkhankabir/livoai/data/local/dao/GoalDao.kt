package com.muhammadsamirkhankabir.livoai.data.local.dao

import androidx.room.*
import com.muhammadsamirkhankabir.livoai.data.local.entities.GoalEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.MilestoneEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals WHERE userId = :userId AND isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun observeGoals(userId: String): Flow<List<GoalEntity>>

    @Query("SELECT * FROM goals WHERE userId = :userId AND isCompleted = 0 AND isDeleted = 0 ORDER BY createdAtEpochMillis DESC LIMIT 1")
    fun observeActiveGoal(userId: String): Flow<GoalEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(goal: GoalEntity)

    @Query("UPDATE goals SET isDeleted = 1, isSynced = 0 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT * FROM milestones WHERE goalId = :goalId ORDER BY orderIndex ASC")
    fun observeMilestones(goalId: String): Flow<List<MilestoneEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMilestone(milestone: MilestoneEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMilestones(milestones: List<MilestoneEntity>)

    @Query("DELETE FROM milestones WHERE id = :id")
    suspend fun deleteMilestone(id: String)
}
