package com.muhammadsamirkhankabir.livoai.ui.screens.finance

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetScreen(onBack: () -> Unit, viewModel: FinanceViewModel = hiltViewModel()) {
    val budget by viewModel.budget.collectAsState()
    val summary by viewModel.summary.collectAsState()
    var limitText by remember(budget) { mutableStateOf(budget?.monthlyLimit?.toString() ?: "") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Monthly budget") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            OutlinedTextField(
                value = limitText, onValueChange = { limitText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Monthly budget limit") }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { limitText.toDoubleOrNull()?.let { viewModel.setBudget(it) } },
                enabled = limitText.toDoubleOrNull() != null,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Save budget") }

            budget?.let { b ->
                Spacer(Modifier.height(24.dp))
                Text("Budget: $${"%.2f".format(b.monthlyLimit)}")
                Text("Spent: $${"%.2f".format(summary.totalExpenses)}")
                Text("Remaining: $${"%.2f".format(b.monthlyLimit - summary.totalExpenses)}")
            }
        }
    }
}
