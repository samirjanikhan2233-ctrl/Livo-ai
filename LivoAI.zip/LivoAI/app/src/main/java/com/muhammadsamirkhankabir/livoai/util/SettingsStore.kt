package com.muhammadsamirkhankabir.livoai.util

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = Constants.PREFS_NAME)

/**
 * Local, non-sensitive user preferences: theme, language, notification toggles,
 * onboarding completion. Nothing security-sensitive is stored here.
 */
@Singleton
class SettingsStore @Inject constructor(private val context: Context) {

    private object Keys {
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val NOTIFICATIONS_TASKS = booleanPreferencesKey("notif_tasks")
        val NOTIFICATIONS_HABITS = booleanPreferencesKey("notif_habits")
        val NOTIFICATIONS_GOALS = booleanPreferencesKey("notif_goals")
        val NOTIFICATIONS_BUDGET = booleanPreferencesKey("notif_budget")
    }

    val themeMode = MutableStateFlow(ThemeMode.SYSTEM)

    suspend fun isOnboardingComplete(): Boolean =
        context.dataStore.data.map { it[Keys.ONBOARDING_DONE] ?: false }.first()

    suspend fun setOnboardingComplete() {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = true }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
        themeMode.value = mode
    }

    suspend fun loadThemeMode() {
        val saved = context.dataStore.data.map { it[Keys.THEME_MODE] }.first()
        themeMode.value = saved?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM
    }

    fun notificationsEnabled(type: String) = when (type) {
        "tasks" -> context.dataStore.data.map { it[Keys.NOTIFICATIONS_TASKS] ?: true }
        "habits" -> context.dataStore.data.map { it[Keys.NOTIFICATIONS_HABITS] ?: true }
        "goals" -> context.dataStore.data.map { it[Keys.NOTIFICATIONS_GOALS] ?: true }
        "budget" -> context.dataStore.data.map { it[Keys.NOTIFICATIONS_BUDGET] ?: true }
        else -> context.dataStore.data.map { true }
    }
}
