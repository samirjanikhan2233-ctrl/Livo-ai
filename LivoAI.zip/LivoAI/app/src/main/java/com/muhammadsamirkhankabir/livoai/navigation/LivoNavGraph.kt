package com.muhammadsamirkhankabir.livoai.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.muhammadsamirkhankabir.livoai.ads.AdManager
import com.muhammadsamirkhankabir.livoai.ui.components.LivoBottomNavBar
import com.muhammadsamirkhankabir.livoai.ui.screens.ai.ChatScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.auth.ForgotPasswordScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.auth.LoginScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.auth.RegisterScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.finance.AddTransactionScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.finance.BudgetScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.finance.FinanceScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.goals.GoalDetailScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.goals.GoalsScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.habits.HabitsScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.home.HomeScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.legal.AboutScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.legal.PrivacyPolicyScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.legal.SupportScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.legal.TermsScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.notes.AddEditNoteScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.notes.NotesScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.onboarding.OnboardingScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.planner.AddEditTaskScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.planner.PlannerScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.premium.PremiumScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.profile.ProfileScreen
import com.muhammadsamirkhankabir.livoai.ui.screens.settings.SettingsScreen

/**
 * Single navigation graph for the whole app. Bottom nav (Home/Planner/Habits/Finance/AI)
 * is shown only on those five top-level destinations; every other screen is a normal
 * full-screen push with its own back button, per Material 3 navigation guidance.
 */
@Composable
fun LivoNavGraph(startDestination: String) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination
    val showBottomBar = Destinations.BOTTOM_NAV_ROUTES.any { route -> currentRoute?.hierarchy?.any { it.route == route } == true }

    // Placeholder AdManager instance wiring: in the real app this comes from Hilt via a
    // small @Composable hiltViewModel-backed holder; simplified here for clarity.
    val adManagerHolder: AdManagerHolder = hiltViewModel()
    val adManager = adManagerHolder.adManager

    androidx.compose.material3.Scaffold(
        bottomBar = { if (showBottomBar) LivoBottomNavBar(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = androidx.compose.ui.Modifier.padding(innerPadding)
        ) {
            composable(Destinations.ONBOARDING) {
                OnboardingScreen(onFinished = { navController.navigate(Destinations.LOGIN) { popUpTo(0) } })
            }
            composable(Destinations.LOGIN) {
                LoginScreen(
                    onLoginSuccess = { navController.navigate(Destinations.HOME) { popUpTo(0) } },
                    onNavigateToRegister = { navController.navigate(Destinations.REGISTER) },
                    onNavigateToForgotPassword = { navController.navigate(Destinations.FORGOT_PASSWORD) }
                )
            }
            composable(Destinations.REGISTER) {
                RegisterScreen(onRegisterSuccess = { navController.navigate(Destinations.HOME) { popUpTo(0) } }, onBack = { navController.popBackStack() })
            }
            composable(Destinations.FORGOT_PASSWORD) {
                ForgotPasswordScreen(onBack = { navController.popBackStack() })
            }

            composable(Destinations.HOME) {
                HomeScreen(
                    onAddTask = { navController.navigate(Destinations.ADD_EDIT_TASK) },
                    onAddHabit = { navController.navigate(Destinations.HABITS) },
                    onAddExpense = { navController.navigate(Destinations.ADD_TRANSACTION) },
                    onAddNote = { navController.navigate(Destinations.ADD_EDIT_NOTE) },
                    onAddGoal = { navController.navigate(Destinations.GOALS) },
                    onAskAi = { navController.navigate(Destinations.AI_CHAT) },
                    onOpenProfile = { navController.navigate(Destinations.PROFILE) },
                    onOpenPremium = { navController.navigate(Destinations.PREMIUM) },
                    adManager = adManager
                )
            }
            composable(Destinations.PLANNER) {
                PlannerScreen(
                    onAddTask = { navController.navigate(Destinations.ADD_EDIT_TASK) },
                    onEditTask = { id -> navController.navigate("${Destinations.ADD_EDIT_TASK}?taskId=$id") },
                    adManager = adManager
                )
            }
            composable(
                "${Destinations.ADD_EDIT_TASK}?taskId={taskId}",
                arguments = listOf(navArgument("taskId") { type = NavType.StringType; nullable = true; defaultValue = null })
            ) { entry ->
                AddEditTaskScreen(taskId = entry.arguments?.getString("taskId"), onDone = { navController.popBackStack() }, onBack = { navController.popBackStack() })
            }

            composable(Destinations.HABITS) { HabitsScreen(adManager = adManager) }

            composable(Destinations.FINANCE) {
                FinanceScreen(
                    onAddTransaction = { navController.navigate(Destinations.ADD_TRANSACTION) },
                    onOpenBudget = { navController.navigate(Destinations.BUDGET) },
                    adManager = adManager
                )
            }
            composable(Destinations.ADD_TRANSACTION) {
                AddTransactionScreen(onDone = { navController.popBackStack() }, onBack = { navController.popBackStack() })
            }
            composable(Destinations.BUDGET) { BudgetScreen(onBack = { navController.popBackStack() }) }

            composable(Destinations.AI_CHAT) { ChatScreen(adManager = adManager) }

            composable(Destinations.NOTES) {
                NotesScreen(
                    onAddNote = { navController.navigate(Destinations.ADD_EDIT_NOTE) },
                    onEditNote = { id -> navController.navigate("${Destinations.ADD_EDIT_NOTE}?noteId=$id") }
                )
            }
            composable(
                "${Destinations.ADD_EDIT_NOTE}?noteId={noteId}",
                arguments = listOf(navArgument("noteId") { type = NavType.StringType; nullable = true; defaultValue = null })
            ) { entry ->
                AddEditNoteScreen(noteId = entry.arguments?.getString("noteId"), onDone = { navController.popBackStack() }, onBack = { navController.popBackStack() })
            }

            composable(Destinations.GOALS) { GoalsScreen(onOpenGoal = { id -> navController.navigate("${Destinations.GOAL_DETAIL}/$id") }) }
            composable(
                "${Destinations.GOAL_DETAIL}/{goalId}",
                arguments = listOf(navArgument("goalId") { type = NavType.StringType })
            ) { entry ->
                GoalDetailScreen(goalId = entry.arguments?.getString("goalId").orEmpty(), onBack = { navController.popBackStack() })
            }

            composable(Destinations.PROFILE) {
                ProfileScreen(
                    onOpenSettings = { navController.navigate(Destinations.SETTINGS) },
                    onOpenPremium = { navController.navigate(Destinations.PREMIUM) },
                    onLoggedOut = { navController.navigate(Destinations.LOGIN) { popUpTo(0) } },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Destinations.SETTINGS) {
                SettingsScreen(
                    onBack = { navController.popBackStack() },
                    onOpenAbout = { navController.navigate(Destinations.ABOUT) },
                    onOpenPrivacy = { navController.navigate(Destinations.PRIVACY_POLICY) },
                    onOpenTerms = { navController.navigate(Destinations.TERMS) },
                    onOpenSupport = { navController.navigate(Destinations.SUPPORT) },
                    onLoggedOut = { navController.navigate(Destinations.LOGIN) { popUpTo(0) } }
                )
            }
            composable(Destinations.PREMIUM) {
                PremiumScreen(
                    onBack = { navController.popBackStack() },
                    onOpenTerms = { navController.navigate(Destinations.TERMS) },
                    onOpenPrivacy = { navController.navigate(Destinations.PRIVACY_POLICY) }
                )
            }
            composable(Destinations.ABOUT) { AboutScreen(onBack = { navController.popBackStack() }) }
            composable(Destinations.PRIVACY_POLICY) { PrivacyPolicyScreen(onBack = { navController.popBackStack() }) }
            composable(Destinations.TERMS) { TermsScreen(onBack = { navController.popBackStack() }) }
            composable(Destinations.SUPPORT) { SupportScreen(onBack = { navController.popBackStack() }) }
        }
    }
}
