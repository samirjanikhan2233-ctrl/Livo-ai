package com.muhammadsamirkhankabir.livoai.gamification

import com.muhammadsamirkhankabir.livoai.data.local.dao.GamificationDao
import com.muhammadsamirkhankabir.livoai.data.local.entities.AchievementEntity
import com.muhammadsamirkhankabir.livoai.data.local.entities.UserProgressEntity
import com.muhammadsamirkhankabir.livoai.util.Constants
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * Healthy, non-manipulative gamification: fixed, transparent XP amounts for real
 * accomplishments (no loot boxes, no streak-loss punishment beyond an honest streak
 * reset, no artificial scarcity or countdown pressure to spend money).
 */
@Singleton
class XpManager @Inject constructor(
    private val dao: GamificationDao
) {
    /** Level curve: level = floor(sqrt(xp / 50)) + 1, i.e. each level needs progressively more XP. */
    fun levelForXp(xp: Int): Int = (sqrt(xp / 50.0)).toInt() + 1

    suspend fun awardXp(userId: String, amount: Int, current: UserProgressEntity?) {
        val newXp = (current?.xp ?: 0) + amount
        dao.upsertProgress(UserProgressEntity(userId, newXp, levelForXp(newXp)))
    }

    suspend fun unlock(userId: String, achievementId: String) {
        dao.upsertAchievement(
            AchievementEntity(
                id = achievementId,
                userId = userId,
                title = DEFAULT_ACHIEVEMENTS[achievementId]?.first ?: achievementId,
                description = DEFAULT_ACHIEVEMENTS[achievementId]?.second ?: "",
                icon = "trophy",
                isUnlocked = true,
                unlockedAtEpochMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun seedDefaultAchievements(userId: String) {
        val defaults = DEFAULT_ACHIEVEMENTS.map { (id, pair) ->
            AchievementEntity(id, userId, pair.first, pair.second, "trophy", isUnlocked = false)
        }
        dao.insertAllAchievements(defaults)
    }

    companion object {
        val DEFAULT_ACHIEVEMENTS = mapOf(
            "FIRST_TASK" to ("First Task" to "Complete your first task"),
            "SEVEN_DAY_STREAK" to ("7 Day Streak" to "Keep any habit going for 7 days straight"),
            "TEN_TASKS" to ("10 Tasks Completed" to "Complete 10 tasks"),
            "FIRST_GOAL" to ("First Goal" to "Create your first goal"),
            "SAVINGS_MILESTONE" to ("Savings Milestone" to "End a month with more income than expenses"),
        )
    }
}
