# Livo AI ProGuard / R8 rules
-keepattributes *Annotation*
-keep class com.muhammadsamirkhankabir.livoai.data.remote.dto.** { *; }
-keep class com.muhammadsamirkhankabir.livoai.data.local.entities.** { *; }
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
