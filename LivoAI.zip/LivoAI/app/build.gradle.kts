import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("kotlin-kapt")
    id("com.google.dagger.hilt.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

// Firebase requires a real google-services.json (from your own Firebase project — see
// README.md "Backend setup"). We apply the plugin conditionally so a fresh checkout
// still builds before you've added your own Firebase config.
val hasGoogleServices = rootProject.file("app/google-services.json").exists()
if (hasGoogleServices) {
    apply(plugin = "com.google.gms.google-services")
}

// Load local, never-committed secrets from local.properties (dev) or CI env vars (release).
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) load(FileInputStream(f))
}
fun secret(name: String): String =
    (localProps.getProperty(name) ?: System.getenv(name) ?: "").also { }

android {
    namespace = "com.muhammadsamirkhankabir.livoai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.muhammadsamirkhankabir.livoai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Client-safe config only. Real secrets (AI key, DB admin creds, payment
        // service-account) live on the backend — see /backend and README.md.
        buildConfigField("String", "BACKEND_BASE_URL", "\"${secret("BACKEND_BASE_URL").ifBlank { "https://api.livoai.app/" }}\"")
        buildConfigField("String", "ADMOB_APP_ID", "\"${secret("ADMOB_APP_ID").ifBlank { "ca-app-pub-3940256099942544~3347511713" }}\"")
        buildConfigField("String", "ADMOB_BANNER_ID", "\"${secret("ADMOB_BANNER_ID").ifBlank { "ca-app-pub-3940256099942544/6300978111" }}\"")
        buildConfigField("String", "ADMOB_REWARDED_ID", "\"${secret("ADMOB_REWARDED_ID").ifBlank { "ca-app-pub-3940256099942544/5224354917" }}\"")

        manifestPlaceholders["admobAppId"] = secret("ADMOB_APP_ID").ifBlank { "ca-app-pub-3940256099942544~3347511713" }
    }

    signingConfigs {
        create("release") {
            val keystoreProps = Properties()
            val keystoreFile = rootProject.file("keystore.properties")
            if (keystoreFile.exists()) {
                keystoreProps.load(FileInputStream(keystoreFile))
                storeFile = file(keystoreProps["storeFile"] as String)
                storePassword = keystoreProps["storePassword"] as String
                keyAlias = keystoreProps["keyAlias"] as String
                keyPassword = keystoreProps["keyPassword"] as String
            }
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = if (rootProject.file("keystore.properties").exists())
                signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        resources.excludes.add("/META-INF/{AL2.0,LGPL2.1}")
    }
}

dependencies {
    // Core / Compose
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")

    // Hilt DI
    implementation("com.google.dagger:hilt-android:2.51.1")
    kapt("com.google.dagger:hilt-android-compiler:2.51.1")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")
    implementation("androidx.hilt:hilt-work:1.2.0")
    kapt("androidx.hilt:hilt-compiler:1.2.0")

    // Room (local DB / offline mode)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    // Retrofit / networking (talks to OUR backend only, never to AI vendor directly)
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    // WorkManager (reminders, background sync)
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // DataStore (settings, theme, session flags)
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Firebase (Auth + Firestore sync + Crashlytics)
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.firebase:firebase-crashlytics-ktx")
    implementation("com.google.firebase:firebase-analytics-ktx")

    // Google Play Billing (subscriptions)
    implementation("com.android.billingclient:billing-ktx:7.1.1")

    // AdMob
    implementation("com.google.android.gms:play-services-ads:23.2.0")

    // Charts (finance breakdown)
    implementation("com.patrykandpatrick.vico:compose-m3:1.14.0")

    // Coil (images)
    implementation("io.coil-kt:coil-compose:2.6.0")

    // Splash Screen API
    implementation("androidx.core:core-splashscreen:1.0.1")

    // Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
