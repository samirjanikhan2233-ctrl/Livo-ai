/**
 * Livo AI — reference backend server.
 *
 * This is what the Android app's LivoBackendApi (Retrofit) talks to.
 * Responsibilities:
 *   1. Verify every request's Firebase ID token (never trust a client-supplied userId).
 *   2. Hold the real AI_API_KEY and call the AI provider server-side.
 *   3. Verify Google Play purchase tokens server-side (never trust "isPremium" from the client).
 *   4. Enforce free-tier AI message limits server-side (the client-side limit is only a UX hint).
 *
 * Run: npm install && npm start   (after copying .env.example to .env and filling it in)
 */
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const admin = require('firebase-admin');
const { google } = require('googleapis');
const fetch = require('node-fetch');
const fs = require('fs');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// ---------- Firebase Admin (verifies the Android app's Firebase Auth ID tokens) ----------
if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON_PATH && fs.existsSync(process.env.FIREBASE_SERVICE_ACCOUNT_JSON_PATH)) {
  admin.initializeApp({
    credential: admin.credential.cert(require(process.env.FIREBASE_SERVICE_ACCOUNT_JSON_PATH)),
  });
} else {
  console.warn('[Livo AI backend] Firebase service account not configured — auth middleware will reject all requests until you add one.');
}

async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing Authorization header.' });
  try {
    const decoded = await admin.auth().verifyIdToken(token);
    req.userId = decoded.uid;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Invalid or expired session. Please log in again.' });
  }
}

// ---------- Simple per-IP rate limiting (defense in depth; per-user limits are in-memory demo below) ----------
app.use('/v1/ai', rateLimit({ windowMs: 60 * 1000, max: 30 }));

// In production replace this in-memory map with Firestore/Redis so limits survive restarts
// and work across multiple server instances.
const dailyMessageCounts = new Map(); // key: `${userId}:${yyyy-mm-dd}` -> count

function isPremiumForUser(userId) {
  // TODO: read the verified subscription status you stored in Firestore during
  // /v1/billing/verify-purchase, instead of this placeholder.
  return false;
}

function checkAndIncrementDailyLimit(userId) {
  const today = new Date().toISOString().slice(0, 10);
  const key = `${userId}:${today}`;
  const count = dailyMessageCounts.get(key) || 0;
  const limit = isPremiumForUser(userId)
    ? Number(process.env.PREMIUM_AI_MESSAGES_PER_DAY || 500)
    : Number(process.env.FREE_AI_MESSAGES_PER_DAY || 15);
  if (count >= limit) return { allowed: false, remaining: 0 };
  dailyMessageCounts.set(key, count + 1);
  return { allowed: true, remaining: limit - count - 1 };
}

// ---------- AI provider call (the ONLY place AI_API_KEY is used) ----------
async function callAiProvider(systemPrompt, history, userMessage) {
  const messages = [
    ...history.map((h) => ({ role: h.role === 'user' ? 'user' : 'assistant', content: h.content })),
    { role: 'user', content: userMessage },
  ];

  const response = await fetch(`${process.env.AI_PROVIDER_BASE_URL}/v1/messages`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.AI_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.AI_MODEL || 'claude-sonnet-4-6',
      max_tokens: 1024,
      system: systemPrompt,
      messages,
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`AI provider error ${response.status}: ${text}`);
  }
  const data = await response.json();
  const textBlock = (data.content || []).find((b) => b.type === 'text');
  return textBlock ? textBlock.text : "I couldn't generate a response. Please try again.";
}

// ---------- AI endpoints ----------
app.post('/v1/ai/chat', requireAuth, async (req, res) => {
  const { message, history = [] } = req.body;
  if (!message || typeof message !== 'string' || message.length > 4000) {
    return res.status(400).json({ error: 'Invalid message.' });
  }
  const limitCheck = checkAndIncrementDailyLimit(req.userId);
  if (!limitCheck.allowed) return res.status(429).json({ error: 'Daily AI message limit reached.' });

  try {
    const reply = await callAiProvider(
      "You are Livo AI, a friendly, practical personal-productivity assistant inside the Livo AI app. " +
        "Help with daily planning, tasks, habits, goals, notes and finance questions. Keep answers concise and actionable. " +
        "For finance questions, remind the user your suggestions are informational, not professional financial advice.",
      history,
      message
    );
    res.json({ reply, remainingMessagesToday: limitCheck.remaining });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'AI provider is currently unavailable.' });
  }
});

app.post('/v1/ai/daily-plan', requireAuth, async (req, res) => {
  const { scheduleDescription, existingTasks = [] } = req.body;
  try {
    const reply = await callAiProvider(
      'You are Livo AI\'s daily planner. Given a free-text description of someone\'s day and their existing tasks, ' +
        'reply ONLY with a JSON array of objects: [{"time":"HH:MM","title":"...","priority":"LOW|MEDIUM|HIGH"}]. No prose.',
      [],
      `Schedule: ${scheduleDescription}\nExisting tasks: ${existingTasks.join(', ')}`
    );
    const plan = JSON.parse(reply.replace(/```json|```/g, '').trim());
    res.json({ plan });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'Could not generate a daily plan right now.' });
  }
});

app.post('/v1/ai/goal-breakdown', requireAuth, async (req, res) => {
  const { goalTitle, goalDescription, targetDate } = req.body;
  try {
    const reply = await callAiProvider(
      'You are Livo AI\'s goal coach. Break the given goal into 4-6 concrete, ordered milestones. ' +
        'Reply ONLY with a JSON array of milestone title strings, e.g. ["Step one", "Step two"]. No prose.',
      [],
      `Goal: ${goalTitle}\nDescription: ${goalDescription}\nTarget date: ${targetDate || 'not set'}`
    );
    const milestones = JSON.parse(reply.replace(/```json|```/g, '').trim());
    res.json({ milestones });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'Could not break down this goal right now.' });
  }
});

app.post('/v1/ai/summarize-note', requireAuth, async (req, res) => {
  const { noteContent } = req.body;
  if (!noteContent) return res.status(400).json({ error: 'noteContent is required.' });
  try {
    const summary = await callAiProvider(
      'Summarize the user\'s note in 2-3 short sentences. Reply with plain text only, no preamble.',
      [],
      noteContent
    );
    res.json({ summary });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'Could not summarize this note right now.' });
  }
});

app.post('/v1/ai/finance-insight', requireAuth, async (req, res) => {
  const { question, totalIncome, totalExpenses, categoryBreakdown } = req.body;
  try {
    const reply = await callAiProvider(
      'You are Livo AI\'s finance assistant. Answer using only the numbers provided. ' +
        'Always make clear this is informational only, not professional financial advice. Keep it under 120 words.',
      [],
      `Question: ${question}\nTotal income: ${totalIncome}\nTotal expenses: ${totalExpenses}\nCategory breakdown: ${JSON.stringify(categoryBreakdown)}`
    );
    res.json({ reply });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'Could not generate a finance insight right now.' });
  }
});

// ---------- Billing verification (server-side Google Play Developer API call) ----------
async function getPlayAndroidPublisher() {
  const auth = new google.auth.GoogleAuth({
    keyFile: process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON_PATH,
    scopes: ['https://www.googleapis.com/auth/androidpublisher'],
  });
  return google.androidpublisher({ version: 'v3', auth });
}

app.post('/v1/billing/verify-purchase', requireAuth, async (req, res) => {
  const { purchaseToken, productId } = req.body;
  if (!purchaseToken || !productId) return res.status(400).json({ error: 'purchaseToken and productId are required.' });

  try {
    const publisher = await getPlayAndroidPublisher();
    const result = await publisher.purchases.subscriptionsv2.get({
      packageName: process.env.GOOGLE_PLAY_PACKAGE_NAME,
      token: purchaseToken,
    });

    const state = result.data.subscriptionState; // e.g. SUBSCRIPTION_STATE_ACTIVE
    const isActive = state === 'SUBSCRIPTION_STATE_ACTIVE' || state === 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD';
    const expiry = result.data.lineItems?.[0]?.expiryTime;

    // TODO: persist { userId: req.userId, productId, isActive, expiry } to your database here,
    // so isPremiumForUser() above (and /v1/billing/subscription-status) reflect real state.

    res.json({
      isPremium: isActive,
      planId: productId,
      expiryEpochMillis: expiry ? new Date(expiry).getTime() : null,
      willRenew: !!result.data.lineItems?.[0]?.autoRenewingPlan?.autoRenewEnabled,
    });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: 'Could not verify this purchase with Google Play right now.' });
  }
});

app.get('/v1/billing/subscription-status', requireAuth, async (req, res) => {
  // TODO: read from your database (populated by verify-purchase above).
  res.json({ isPremium: isPremiumForUser(req.userId), planId: null, expiryEpochMillis: null, willRenew: false });
});

// ---------- Sync (minimal example; extend per entity) ----------
app.post('/v1/sync/push', requireAuth, async (req, res) => {
  // TODO: upsert req.body.tasks / habits / goals / notes / transactions into your database,
  // scoped to req.userId only.
  const syncedIds = (req.body.tasks || []).map((t) => t.id);
  res.json({ success: true, syncedIds });
});

app.get('/v1/sync/pull', requireAuth, async (req, res) => {
  // TODO: return everything changed for req.userId since ?since= timestamp.
  res.json({ serverTimestamp: Date.now(), changes: {} });
});

// ---------- Account deletion ----------
app.post('/v1/account/delete', requireAuth, async (req, res) => {
  try {
    await admin.auth().deleteUser(req.userId);
    // TODO: also delete req.userId's rows from your database.
    res.json({ success: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Could not delete account right now.' });
  }
});

app.get('/health', (req, res) => res.json({ status: 'ok' }));

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Livo AI backend listening on port ${port}`));
